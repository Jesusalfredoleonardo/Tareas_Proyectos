package Dibujo_Gato;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.Stroke;
import java.awt.geom.AffineTransform;
import java.awt.geom.Ellipse2D;

/**
 * 
 * @author PC EXPRESS NAVOJOA
 * Ventana principal que muestra el panel con los dibujos
 */
public class frmDibujos extends javax.swing.JFrame {

    /**
     * Creates new form FrmDibujos
     */
    public frmDibujos() {
        initComponents();
    }
    @Override
    public void paint(Graphics g) {
        super.paint(g);  // llama al metodo original para limpiar el fondo antes de dibujar
        Graphics2D g2d = (Graphics2D) g;  // convierte el grafico base a 2D para usar mas funciones
        AffineTransform originalTransform = g2d.getTransform();  // guarda la posicion y rotacion original del dibujo
        g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);  // activa suavizado de bordes
        g2d.setStroke(new BasicStroke(7));  // define el grosor inicial de las lineas
        g2d.setColor(Color.black);  // establece el color negro
        Stroke originalStroke = g2d.getStroke();  // guarda el grosor original

        
        // TRES PELITOS DEL GATO Y PARTE DE LA CABEZA
        g2d.setStroke(new BasicStroke(13));  // grosor mas grande para marcar la frente
        g2d.drawLine(270, 210, 270, 201);  // primera linea vertical
        g2d.drawLine(293, 210, 293, 201);  // segunda linea vertical
        g2d.drawLine(315, 210, 315, 201);  // tercera linea vertical
        g2d.setStroke(originalStroke);  // regresa al grosor original
        g2d.drawArc(267, 216, 6, 6, 0, 360);  // primer circulo pequeño que forma la parte redondeada de los tres pelitos del gato
        g2d.drawArc(290, 216, 6, 6, 0, 360);  // segundo circulo pequeño
        g2d.drawArc(312, 216, 6, 6, 0, 360);  // tercer circulo pequeño
        g2d.drawArc(258, 198, 75, 0, 50, 90);  // arco superior de la cabeza

        // OREJA IZQUIERDA
        g2d.drawLine(264, 197, 241, 172);  // conecta cabeza con oreja
        // PUNTA OREJA IZQUIERDA
        g2d.drawArc(176,162,90, 200, 69, 56);  // forma la curva de la oreja

        // OREJA DERECHA
        g2d.drawLine(323, 197, 340, 172);  // conecta cabeza con oreja derecha
        // PUNTA OREJA DERECHA
        g2d.drawArc(316,160,92, 200, 60, 53);  // curva superior de la oreja derecha

        // DOS OJOS
        g2d.setColor(Color.black);  
        g2d.fillArc(342, 249, 23, 23, 0, 360);  // ojo derecho relleno
        g2d.fillArc(222, 250, 23, 23, 0, 360);  // ojo izquierdo relleno

        // NARIZ Y LENJUA 
        g2d.drawArc(271, 247, 20, 21, 180, 180);  // curva izquierda de la nariz
        g2d.drawArc(294, 246, 20, 21, 180, 190);  // curva derecha de la nariz
        g2d.drawArc(291, 250, 3, 3, 0, 360);  // punto central de la nariz
        g2d.drawArc(282, 257, 22, 25, 180, 180);  // lengua del gato
        
        // BIGOTES
        g2d.drawArc(-25, 242, 220, 50, 30, 40);  // bigote izquierdo superior
        g2d.fillArc(117, 239, 8, 8, 0, 360); 
        g2d.fillArc(180, 252, 8, 8, 0, 360);
        g2d.drawArc(90, 270, 100, 30, 50, 70);  // bigote izquierdo inferior
        g2d.fillArc(108, 270, 8, 8, 0, 360); 
        g2d.fillArc(170, 270, 8, 8, 0, 360);
        g2d.drawArc(402, 235, 135, 50, 95, 60);  // bigote derecho superior
        g2d.fillArc(403, 246, 8, 8, 0, 360); 
        g2d.fillArc(464, 231, 8, 8, 0, 360);
        g2d.drawArc(400, 265, 80, 15, 40, 100);  // bigote derecho inferior
        g2d.fillArc(400, 265, 8, 8, 0, 360); 
        g2d.fillArc(468, 264, 8, 8, 0, 360);

        // PARTE IZQUIERDA DEL GATO
        g2d.setStroke(new BasicStroke(7));  // definimos un grosor de 7 
        AffineTransform ladoizq = new AffineTransform();  // con esta transformacion rotamos el arco
        ladoizq.rotate(Math.toRadians(115),272,218);  // rota el arco hacia el lado izquierdo
        g2d.setTransform(ladoizq);  // aplica la rotacion
        g2d.setStroke(new BasicStroke(8));  // grosor un poco mayor para el contorno
        g2d.drawArc(272,218,290,30,215,140);  // dibuja el arco lateral izquierdo
        g2d.setTransform(originalTransform);  // regresa a la posicion original

        // LADO DERECHO DEL GATO
        AffineTransform ladoder = new AffineTransform();  // crea nueva transformacion
        ladoder.rotate(Math.toRadians(245),630,573);  // rota hacia el lado derecho
        g2d.setTransform(ladoder);  // aplica la rotacion
        g2d.setStroke(new BasicStroke(8));  // mismo grosor que el lado izquierdo
        g2d.drawArc(630,573,382,30,260,89);  // dibuja el arco lateral derecho
        g2d.setTransform(originalTransform);  // restaura la transformacion original

        // VASO CON PAPAS (PARTE INFERIOR DEL GATO)
        g2d.drawLine(238, 500, 384, 500);  // borde superior del vaso
        g2d.drawArc(215, 500, 36, 35, 90, 95);  // curva izquierda del vaso
        g2d.drawArc(370, 500, 35, 30, -10, 93);  // curva derecha del vaso
        g2d.drawLine(215, 522, 245, 640);  // borde lateral izquierdo
        g2d.drawArc(247, 630, 50, 28, 190, 90);  // base curva del vaso
        g2d.drawLine(280, 658, 348, 658);  // linea inferior del vaso
        g2d.drawArc(330, 598, 50, 60, 270, 80);  // curva interior derecha
        g2d.drawLine(404, 520, 379, 635);  // borde lateral derecho
        g2d.drawLine(230, 555, 395, 555);  // linea media del vaso
        g2d.drawLine(240, 610, 380, 610);  // linea inferior del vaso

        // 1RA PAPA FRITA
        g2d.drawLine(238, 435, 242, 495);  // linea de la papa
        g2d.drawArc(238, 420, 30, 25, 10, 155);  // parte curva superior
        g2d.drawLine(268, 435, 275, 495);  // lado derecho

        // 2DA PAPA FRITA
        g2d.drawLine(270, 425, 275, 495);  // linea izquierda
        g2d.drawArc(270, 410, 30, 25, 10, 160);  // parte de arriba
        g2d.drawLine(300, 425, 304, 495);  // lado derecho

        // 3RA PAPA FRITA
        g2d.drawLine(307, 429, 307, 495);  // linea central
        g2d.drawArc(307, 410, 33, 32, 2, 168);  // parte curva superior
        g2d.drawLine(340, 430, 340, 495);  // lado derecho

        // 4TA PAPA FRITA
        g2d.drawLine(345, 433, 343, 495);  // linea izquierda
        g2d.drawArc(346, 416, 28, 32, 2, 168);  // curva superior
        g2d.drawLine(374, 435, 373, 495);  // lado derecho

        // PAN SUPERIOR DE LA HAMBURGESA
        g2d.drawArc(40, 374, 210, 126, 15, 143);  // curva principal del pan
        g2d.drawArc(20, 380, 250, 180, 145, 60);  // curva extra del pan
        g2d.drawArc(-30, 370, 270, 150, 280, 40);  // parte base del pan

        AffineTransform pan1 = new AffineTransform();
        pan1.rotate(Math.toRadians(-22),152,595);  // gira un poco el arco
        g2d.setTransform(pan1);
        g2d.setStroke(new BasicStroke(9));  // trazo mas grueso
        g2d.drawArc(152, 595, 150, 60, 290, 30);  // parte baja del pan
        g2d.setTransform(originalTransform);

        AffineTransform pan2 = new AffineTransform();
        pan2.rotate(Math.toRadians(-12),40,605);  // rotacion leve
        g2d.setTransform(pan2);
        g2d.drawArc(40, 605, 750, 80, 200, 25);  // parte grande del pan
        g2d.setTransform(originalTransform);

        AffineTransform pan3 = new AffineTransform();
        pan3.rotate(Math.toRadians(11),44,634);  // rotacion leve contraria
        g2d.setTransform(pan3);
        g2d.drawArc(44, 634, 42, 12, 205, 70);  // curva chica del borde
        g2d.setTransform(originalTransform);
       
        // SEMILLITAS DEL PAN
        AffineTransform semilla1 = new AffineTransform();
        semilla1.rotate(Math.toRadians(11),86,570);  // inclinacion ligera
        g2d.setTransform(semilla1);
        g2d.draw(new Ellipse2D.Double(86,570,35,18));  // primera semilla
        g2d.draw(new Ellipse2D.Double(200,520,35,18));  // segunda semilla
        g2d.draw(new Ellipse2D.Double(125,500,35,18));  // tercera semilla
        g2d.setTransform(originalTransform);

        // LECHUGA
        AffineTransform lechuga1 = new AffineTransform();
        lechuga1.rotate(Math.toRadians(11),48,650);  // giro leve
        g2d.setTransform(lechuga1);
        g2d.setColor(Color.black);
        g2d.drawArc(48, 650, 35, 40, 150, 160);  // hoja de lechuga
        g2d.setTransform(originalTransform);

        g2d.drawLine(49, 521, 43, 524);  // pequeño detalle lateral
        g2d.setStroke(new BasicStroke(7));  // linea mas gruesa
        g2d.drawArc(53, 543, 40, 45, 40, 90);  // curva de la lechuga
        g2d.setStroke(originalStroke);
        g2d.drawArc(83, 515, 45, 45, 220, 100);  // otra hoja
        g2d.drawArc(123, 537, 45, 45, 70, 75);  // otra mas
        g2d.drawArc(140, 497, 60, 45, 250, 60);  // parte central
        g2d.drawArc(200, 505, 30, 40, 80, 80);  // curva lateral

        AffineTransform lechuga2 = new AffineTransform();
        lechuga2.rotate(Math.toRadians(-30),215,650);  // giro contrario
        g2d.setTransform(lechuga2);
        g2d.setStroke(new BasicStroke(9));  // linea mas ancha
        g2d.drawArc(215, 658, 30, 20, 275, 65);  // borde de la hoja
        g2d.setStroke(originalStroke);
        g2d.setTransform(originalTransform);

        // CARNE D LA HAMBURGESA
        AffineTransform carne = new AffineTransform();
        carne.rotate(Math.toRadians(-190),295,690);  // rotacion de la carne
        g2d.setTransform(carne);
        g2d.drawArc(295, 695, 322, 70, 80, 70);  // arco grande de la carne
        g2d.setTransform(originalTransform);

        AffineTransform carne1 = new AffineTransform();
        carne1.rotate(Math.toRadians(-110),85,730);  // otra parte de la carne
        g2d.setTransform(carne1);
        g2d.drawArc(85, 730, 80, 90, 90, 60);  // arco lateral
        g2d.setTransform(originalTransform);

        // PAN DE ABAJO 
        AffineTransform panpan = new AffineTransform();
        panpan.rotate(Math.toRadians(-120),100,790);  // giro del pan
        g2d.setTransform(panpan);
        g2d.drawArc(100, 790, 100, 190, 50, 75);  // curva del pan de abajo
        g2d.setTransform(originalTransform);

        AffineTransform panpan1 = new AffineTransform();
        panpan1.rotate(Math.toRadians(-190),325,735);  // rotacion para la otra mitad
        g2d.setTransform(panpan1);
        g2d.drawArc(325, 740, 268, 50, 52, 82);  // parte derecha del pan
        g2d.setTransform(originalTransform);

        // REFRESCO
        AffineTransform Refresco = new AffineTransform();
        Refresco.rotate(Math.toRadians(-170),690,590);  // inclina el vaso
        g2d.setTransform(Refresco);
        g2d.setStroke(new BasicStroke(11));  // trazo grueso
        g2d.drawArc(690, 590, 230, 70, 20, 238); //PRIMER ARCO
        g2d.drawArc(690, 590, 230, 70, 282, 87); //SEGUNDO ARCO
        
  // parte superior del vaso 590 ES Y, - ABAJO + ARRIBA
        
        // 690 ES X - derecha + izquirda... 
        g2d.setTransform(originalTransform);

        // VASO
        g2d.setColor(Color.black); // se pone el color negro para dibujar el vaso
        g2d.drawLine(386, 468, 386, 495); // linea vertical que forma parte del cuerpo del vaso

        // POPOTE
        g2d.drawLine(473, 345, 458, 415); // linea izquierda del popote (parte de arriba hacia abajo)
        g2d.drawLine(500, 356, 485, 425); // linea derecha del popote (paralela a la anterior)  
        
        g2d.drawArc(458, 415, 29, 15, 0, -180);   
        
        g2d.drawLine(495, 330, 530, 332); // parte superior del popote (horizontal)
        g2d.drawLine(502, 355, 528, 357); // linea paralela a la anterior (refuerza la parte superior)
        g2d.drawArc(475, 330, 30, 20, 90, 85); // curva que forma la union izquierda del popote con la parte superior
        g2d.drawArc(525, 333, 25, 25, -90, 180); // curva que forma la parte derecha de la boca del popote

       // TAPADERA VASO
       g2d.drawLine(380, 430, 380, 460); // linea vertical izquierda de la tapa     
       g2d.drawArc(376, 400, 300, 100, 200, 70); 
       g2d.drawArc(476, 400, 90, 100, 260, 55);
       g2d.drawLine(422, 448, 416, 477); // linea diagonal interna de la tapa 
       g2d.drawLine(468, 460, 462, 490); // linea inclinada hacia el centro  
       g2d.drawLine(518, 465, 515, 495); // linea diagonal hacia la derecha 
       g2d.drawLine(555, 455, 555, 480); // borde vertical derecho de la tapa

       // LINEA DERECHA DEL VASO
       g2d.drawLine(535, 498, 500, 610); // linea diagonal que baja desde la tapa hacia el cuerpo del vaso

       // TRANSFORMACION PARA GIRAR PARTE INFERIOR DEL VASO
       AffineTransform vaso = new AffineTransform(); // crea un objeto para rotar el dibujo
       vaso.rotate(Math.toRadians(-160), 650, 700); // aplica rotacion de -160 grados con punto central (650,700)
       g2d.setTransform(vaso); // establece la rotacion en el grafico
       g2d.drawArc(650, 700, 300, 100, 90, 70); // dibuja arco grande, parte superior del vaso
       g2d.drawArc(690, 400, 300, 100, 90, 70);
       g2d.setTransform(originalTransform); // restaura el estado original del grafico

       // segundo arco del vaso
       AffineTransform vaso2 = new AffineTransform(); // nueva transformacion
       vaso2.rotate(Math.toRadians(-160), 630, 760); // rotacion similar para el siguiente arco
       g2d.setTransform(vaso2); // aplica la rotacion
       g2d.drawArc(630, 760, 280, 100, 90, 70); // dibuja segundo arco inferior del vaso
       g2d.setTransform(originalTransform); // restaura transformacion original

       // tercer arco del vaso
       AffineTransform vaso3 = new AffineTransform(); // nueva transformacion
       vaso3.rotate(Math.toRadians(-165), 610, 800); // rotacion un poco diferente (-165 grados)
       g2d.setTransform(vaso3); // aplica rotacion 
       //PARTE QUE ESTOY MODIGICANDO
       g2d.drawArc(606, 802, 160, 60, 90, 85); // dibuja arco mas pequeño (parte inferior)
       g2d.setTransform(originalTransform); // regresa al estado normal

       // cuarto arco del vaso (base final)
       AffineTransform vaso4 = new AffineTransform(); // otra transformacion
       vaso4.rotate(Math.toRadians(-80), 490, 770); // rotacion distinta (-80 grados)
       g2d.setTransform(vaso4); // aplica la rotacion
       g2d.drawArc(490, 768, 100, 98, 90, 80); // dibuja la base final del vaso   
       g2d.setStroke(originalStroke); // restaura el grosor de linea original
       g2d.setTransform(originalTransform); // regresa a la orientacion inicial
     }
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Proyecto Dibujo");
        setPreferredSize(new java.awt.Dimension(600, 680));
        setResizable(false);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 555, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 449, Short.MAX_VALUE)
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(frmDibujos.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(frmDibujos.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(frmDibujos.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(frmDibujos.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new frmDibujos().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    // End of variables declaration//GEN-END:variables
}
