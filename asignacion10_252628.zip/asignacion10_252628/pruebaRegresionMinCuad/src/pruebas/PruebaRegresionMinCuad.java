package pruebas;

import implementaciones.RegresionMinCuad;
import com.mycompany.gausssolver.MetodosEcuaciones;
import com.mycompany.gausssolver.MetodosEcuaciones.GaussStep;
import java.awt.*;
import java.awt.event.*;
import java.text.DecimalFormat;
import java.util.List;
import javax.swing.*;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableCellRenderer;

/**
 * PruebaRegresionMinCuad - JFrame principal
 * Interfaz completa que muestra:
 * - tablas de entrada (puntos)
 * - tabla de calculos / sumatorias (visual como en PDF)
 * - tabla con la matriz aumentada que se resolvio
 * - panel lateral con pasos y vista por paso (antes/despues)
 *
 * Se agrego:
 * - validacion para que la tabla de entrada acepte solo numeros (mensaje en espanol)
 * - ocultamiento de paneles de pasos/detalle cuando se usa regresion lineal grado 1
 * - las tablas de resultados no son editables
 * @author PC EXPRESS NAVOJOA
 */

public class PruebaRegresionMinCuad extends JFrame {

    private final RegresionMinCuad reg = new RegresionMinCuad();
    private final DecimalFormat df = new DecimalFormat("0.000000");

    // componentes principales
    private final JComboBox<String> cbTipo;
    private final DefaultTableModel modelInput;
    private final JTable tableInput;
    private final DefaultTableModel modelCalculos;
    private final JTable tableCalculos;
    private final DefaultTableModel modelMatriz; // matriz aumentada visual
    private final JTable tableMatriz;
    private final DefaultListModel<String> pasosListModel;
    private final JList<String> listPasos;
    private List<GaussStep> pasosActuales; // pasos obtenidos tras Gauss

    private final JTextArea txtResultado;
    private final JButton btnEj1, btnEj2, btnEj3, btnCalcular, btnLimpiar;

    // paneles para ocultar/mostrar
    private final JPanel panelPasos;
    private final JPanel panelDetalle;

    public PruebaRegresionMinCuad() {
        super("Regresion por Minimos Cuadrados - Interfaz (con pasos)");
        setLayout(new BorderLayout(8, 8));
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setSize(1200, 760);
        setLocationRelativeTo(null);
        setResizable(false);

        // TOP panel con controles
        JPanel top = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 10));
        cbTipo = new JComboBox<>(new String[] {
            "Regresion lineal (grado 1)",
            "Regresion polinomial (grado n)",
            "Regresion lineal multiple (n variables)"
        });
        btnEj1 = new JButton("Ejemplo Lineal");
        btnEj2 = new JButton("Ejemplo Polinomio");
        btnEj3 = new JButton("Ejemplo Multiple");
        btnCalcular = new JButton("Calcular");
        btnLimpiar = new JButton("Limpiar");

        top.add(new JLabel("Tipo:"));
        top.add(cbTipo);
        top.add(btnEj1);
        top.add(btnEj2);
        top.add(btnEj3);
        top.add(btnCalcular);
        top.add(btnLimpiar);
        add(top, BorderLayout.NORTH);

        // PANEL CENTRAL: tablas principales (izq) y panel lateral (der)
        JPanel center = new JPanel(new BorderLayout(8, 8));

        // Subpanel de tablas (entrada + calculos + matriz)
        JPanel tablasPanel = new JPanel();
        tablasPanel.setLayout(new BoxLayout(tablasPanel, BoxLayout.Y_AXIS));

        // tabla de entrada (editable)
        modelInput = new DefaultTableModel(new Object[][]{}, new String[]{"x", "y"});
        tableInput = new JTable(modelInput);
        tableInput.setRowHeight(26);
        JScrollPane spInput = new JScrollPane(tableInput);
        spInput.setPreferredSize(new Dimension(760, 180));
        spInput.setBorder(BorderFactory.createTitledBorder("Puntos (editar o cargar ejemplo)"));
        tablasPanel.add(spInput);

        // tabla de calculos (sumatorias) -> NO editable
        modelCalculos = new DefaultTableModel();
        tableCalculos = new JTable(modelCalculos) {
            @Override public boolean isCellEditable(int row, int column) { return false; }
        };
        tableCalculos.setRowHeight(26);
        JScrollPane spCalc = new JScrollPane(tableCalculos);
        spCalc.setPreferredSize(new Dimension(760, 200));
        spCalc.setBorder(BorderFactory.createTitledBorder("Calculos intermedios y sumatorias"));
        tablasPanel.add(Box.createRigidArea(new Dimension(0,6)));
        tablasPanel.add(spCalc);

        // tabla matriz aumentada -> NO editable
        modelMatriz = new DefaultTableModel();
        tableMatriz = new JTable(modelMatriz) {
            @Override public boolean isCellEditable(int row, int column) { return false; }
        };
        tableMatriz.setRowHeight(26);
        JScrollPane spMat = new JScrollPane(tableMatriz);
        spMat.setPreferredSize(new Dimension(760, 180));
        spMat.setBorder(BorderFactory.createTitledBorder("Matriz aumentada (la que se resolvio)"));
        tablasPanel.add(Box.createRigidArea(new Dimension(0,6)));
        tablasPanel.add(spMat);

        center.add(tablasPanel, BorderLayout.CENTER);

        // PANEL LATERAL: pasos y vista
        JPanel lateral = new JPanel();
        lateral.setLayout(new BorderLayout(6,6));
        pasosListModel = new DefaultListModel<>();
        listPasos = new JList<>(pasosListModel);
        listPasos.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        JScrollPane spPasos = new JScrollPane(listPasos);
        spPasos.setPreferredSize(new Dimension(380, 300));
        spPasos.setBorder(BorderFactory.createTitledBorder("Pasos Gauss-Jordan"));

        // area para detalle de paso (matriz textual o texto descriptivo)
        JTextArea txtPasoDetalle = new JTextArea();
        txtPasoDetalle.setEditable(false);
        JScrollPane spPasoDet = new JScrollPane(txtPasoDetalle);
        spPasoDet.setPreferredSize(new Dimension(380, 200));
        spPasoDet.setBorder(BorderFactory.createTitledBorder("Detalle paso / matriz"));

        // envolver en paneles para ocultar
        panelPasos = new JPanel(new BorderLayout());
        panelPasos.add(spPasos, BorderLayout.CENTER);
        panelDetalle = new JPanel(new BorderLayout());
        panelDetalle.add(spPasoDet, BorderLayout.CENTER);

        lateral.add(panelPasos, BorderLayout.NORTH);
        lateral.add(panelDetalle, BorderLayout.CENTER);

        center.add(lateral, BorderLayout.EAST);

        add(center, BorderLayout.CENTER);

        // AREA RESULTADO abajo
        txtResultado = new JTextArea(6, 110);
        txtResultado.setEditable(false);
        JScrollPane spRes = new JScrollPane(txtResultado);
        spRes.setBorder(BorderFactory.createTitledBorder("Resultado"));
        add(spRes, BorderLayout.SOUTH);

        // EVENTOS
        btnEj1.addActionListener((e) -> cargarEjemploLineal());
        btnEj2.addActionListener((e) -> cargarEjemploPolinomio());
        btnEj3.addActionListener((e) -> cargarEjemploMultiple());
        btnCalcular.addActionListener((e) -> calcularSeleccionado());
        btnLimpiar.addActionListener((e) -> limpiarTodo());
        cbTipo.addActionListener((e) -> ajustarTablaSegunTipo());

        // cuando el usuario selecciona un paso actualizar detalle y tabla matriz segun snapshot
        listPasos.addListSelectionListener(evt -> {
            int idx = listPasos.getSelectedIndex();
            if (idx >= 0 && pasosActuales != null && idx < pasosActuales.size()) {
                GaussStep gs = pasosActuales.get(idx);
                // detalle textual
                txtPasoDetalle.setText(gs.descripcion);
                // mostrar snapshot en la tabla matriz
                mostrarMatrizEnTabla(gs.matriz);
            }
        });

        // estilo tablas: centrar celdas y ajustar anchos similares al PDF
        centrarYFormatearTablas();

        // Aplicar restricciones y estados iniciales:
        // - restringir solo numeros en la tabla de entrada
        restringirSoloNumeros(tableInput);
        // - ocultar los paneles de pasos por defecto (se mostraran para polinomial/multiple)
        panelPasos.setVisible(false);
        panelDetalle.setVisible(false);

        // Inicializar la tabla segun tipo seleccionado (por defecto index 0)
        ajustarTablaSegunTipo();

        setVisible(true);
    }

    //  Metodo que fuerza que la tabla solo acepte numeros (y muestra mensaje)
    private void restringirSoloNumeros(JTable tabla) {
        // Default editor para Object.class usando JTextField, con validacion en stopCellEditing
        tabla.setDefaultEditor(Object.class, new DefaultCellEditor(new JTextField()) {
            @Override
            public boolean stopCellEditing() {
                Object valObj = getCellEditorValue();
                String valor = (valObj == null) ? "" : valObj.toString();
                if (valor != null && !valor.trim().isEmpty()) {
                    try {
                        // aceptar tanto formato "123" como "123.45" y "-1.2"
                        Double.parseDouble(valor.trim());
                    } catch (NumberFormatException e) {
                        // mensaje en espanol como pediste
                        JOptionPane.showMessageDialog(tabla,
                                "Solo se permiten valores numericos en la tabla.",
                                "Entrada no valida",
                                JOptionPane.ERROR_MESSAGE);
                        return false; // no permite terminar la edicion hasta corregir
                    }
                }
                return super.stopCellEditing();
            }
        });
    }

    // Ajustes visuales para las tablas
    private void centrarYFormatearTablas() {
        DefaultTableCellRenderer centerRenderer = new DefaultTableCellRenderer();
        centerRenderer.setHorizontalAlignment(SwingConstants.CENTER);
        tableInput.setDefaultRenderer(Object.class, centerRenderer);
        tableCalculos.setDefaultRenderer(Object.class, centerRenderer);
        tableMatriz.setDefaultRenderer(Object.class, centerRenderer);

        tableCalculos.setFont(new Font(Font.MONOSPACED, Font.PLAIN, 13));
        tableMatriz.setFont(new Font(Font.MONOSPACED, Font.PLAIN, 13));
        ajustarAnchoColumnas(tableInput);
        ajustarAnchoColumnas(tableCalculos);
        ajustarAnchoColumnas(tableMatriz);
    }

    // Ajusta las columnas/filas segun tipo; tambien oculta/ muestra paneles de pasos
    private void ajustarTablaSegunTipo() {
        int tipo = cbTipo.getSelectedIndex();
        if (tipo == 2) {
            inicializarInput(8, 3); // x1, x2, y
        } else {
            inicializarInput(12, 2); // x, y
        }
        // Mostrar u ocultar paneles segun tipo
        if (tipo == 0) { // Lineal grado 1
            panelPasos.setVisible(false);
            panelDetalle.setVisible(false);
        } else {
            panelPasos.setVisible(true);
            panelDetalle.setVisible(true);
        }

        modelCalculos.setRowCount(0);
        modelCalculos.setColumnCount(0);
        modelMatriz.setRowCount(0);
        modelMatriz.setColumnCount(0);
        pasosListModel.clear();
        txtResultado.setText("");
    }

    // Inicializa tabla de entrada con filas y columnas indicadas
    private void inicializarInput(int filas, int cols) {
        modelInput.setRowCount(0);
        String[] headers = new String[cols];
        for (int j = 0; j < cols; j++) {
            if (cols == 2) headers[j] = j==0 ? "x" : "y";
            else headers[j] = (j < cols-1) ? "x" + (j+1) : "y";
        }
        modelInput.setColumnIdentifiers(headers);
        for (int i = 0; i < filas; i++) {
            Object[] r = new Object[cols];
            for (int j = 0; j < cols; j++) r[j] = "0";
            modelInput.addRow(r);
        }
        // re-aplicar la restriccion de solo numeros (por si se recreo la tabla/modelo)
        restringirSoloNumeros(tableInput);
    }

    // Limpia todo
    private void limpiarTodo() {
        modelInput.setRowCount(0);
        modelInput.setColumnCount(0);
        modelCalculos.setRowCount(0);
        modelCalculos.setColumnCount(0);
        modelMatriz.setRowCount(0);
        modelMatriz.setColumnCount(0);
        pasosListModel.clear();
        pasosActuales = null;
        txtResultado.setText("");
        ajustarTablaSegunTipo();
    }

    // Lee datos de la tabla de entrada y devuelve matriz de double
    private double[][] leerPuntosDesdeTabla() throws Exception {
        int filas = modelInput.getRowCount();
        int cols = modelInput.getColumnCount();
        java.util.List<double[]> rows = new java.util.ArrayList<>();
        for (int i = 0; i < filas; i++) {
            boolean filaVacia = true;
            double[] vals = new double[cols];
            for (int j = 0; j < cols; j++) {
                Object v = modelInput.getValueAt(i, j);
                if (v != null && !v.toString().trim().isEmpty()) {
                    // aqui el parseo puede lanzar NumberFormatException
                    try {
                        vals[j] = Double.parseDouble(v.toString().trim());
                        filaVacia = false;
                    } catch (NumberFormatException nf) {
                        // si llegamos aqui, significa que hay texto invalido sin validar
                        throw new Exception("Valor invalido en fila " + (i+1) + ", columna " + (j+1) + ". Use solo numeros.");
                    }
                } else {
                    vals[j] = 0.0;
                }
            }
            if (!filaVacia) rows.add(vals);
        }
        if (rows.isEmpty()) throw new Exception("No hay puntos ingresados.");
        double[][] pts = new double[rows.size()][];
        for (int i = 0; i < rows.size(); i++) pts[i] = rows.get(i);
        return pts;
    }

    // Maneja boton calcular según tipo seleccionado
    private void calcularSeleccionado() {
        int tipo = cbTipo.getSelectedIndex();
        try {
            double[][] puntos = leerPuntosDesdeTabla(); // valida numeros aqui tambien
            if (tipo == 0) {
                procesarLineal(puntos);
            } else if (tipo == 1) {
                String s = JOptionPane.showInputDialog(this, "Introduce grado del polinomio (n):", "2");
                if (s == null) return;
                int n = Integer.parseInt(s.trim());
                procesarPolinomial(puntos, n);
            } else {
                procesarMultiple(puntos);
            }
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    // Carga ejemplo lineal
    private void cargarEjemploLineal() {
        double[][] puntos1 = {
            {1, 9.9}, {2, 9.0}, {3, 8.1}, {4, 7.1},
            {5, 6.2}, {6, 5.3}, {7, 4.4}, {8, 3.6},
            {9, 2.7}, {10, 1.8}, {11, 1.0}, {12, -0.7},
            {13, -1.5}, {14, -2.3}
        };
        inicializarInput(puntos1.length, 2);
        for (int i = 0; i < puntos1.length; i++) {
            modelInput.setValueAt(df.format(puntos1[i][0]), i, 0);
            modelInput.setValueAt(df.format(puntos1[i][1]), i, 1);
        }
    }

    // Carga ejemplo polinomio
    private void cargarEjemploPolinomio() {
        double[][] puntos2 = {
            {0, 1.2}, {2, 0.6}, {4, 0.4}, {6, -0.2}, {9, 0.0},
            {11, -0.6}, {13, -0.4}, {15, -0.2}, {17, -0.4},
            {19, 0.2}, {23, 0.4}, {25, 1.2}
        };
        inicializarInput(puntos2.length, 2);
        for (int i = 0; i < puntos2.length; i++) {
            modelInput.setValueAt(df.format(puntos2[i][0]), i, 0);
            modelInput.setValueAt(df.format(puntos2[i][1]), i, 1);
        }
    }

    // Carga ejemplo multiple
    private void cargarEjemploMultiple() {
        double[][] puntos3 = {
            {1,1,18}, {1,2,12.8}, {2,1,25.7}, {2,2,20.6},
            {3,1,35.0}, {3,2,29.8}, {4,1,45.5}, {4,2,40.3}
        };
        inicializarInput(puntos3.length, 3);
        for (int i = 0; i < puntos3.length; i++) {
            for (int j = 0; j < 3; j++) {
                modelInput.setValueAt(df.format(puntos3[i][j]), i, j);
            }
        }
    }

    // procesamiento regresion lineal (grado 1)
    private void procesarLineal(double[][] puntos) {
        int m = puntos.length;
        modelCalculos.setDataVector(new Object[0][0], new Object[] {"xi", "yi", "xi^2", "xi*yi"});
        double sumx=0, sumy=0, sumx2=0, sumxy=0;
        for (int i = 0; i < m; i++) {
            double x = puntos[i][0], y = puntos[i][1];
            double x2 = x*x, xy = x*y;
            modelCalculos.addRow(new Object[] { df.format(x), df.format(y), df.format(x2), df.format(xy) });
            sumx += x; sumy += y; sumx2 += x2; sumxy += xy;
        }
        modelCalculos.addRow(new Object[] { df.format(sumx), df.format(sumy), df.format(sumx2), df.format(sumxy) });

        double n = m;
        double a1 = ((n*sumxy) - (sumx*sumy)) / ((n*sumx2) - (sumx*sumx));
        double a0 = (sumy - a1*sumx) / n;

        txtResultado.setText("Regresion Lineal:\n" + "y = " + df.format(a0) + " + " + df.format(a1) + " x\n" +
                "a0 = " + df.format(a0) + "\n" + "a1 = " + df.format(a1));
        // construir matriz aumentada para mostrar (2x3) y mostrarla
        double[][] mat = new double[2][3];
        mat[0][0] = m; mat[0][1] = sumx; mat[0][2] = sumy;
        mat[1][0] = sumx; mat[1][1] = sumx2; mat[1][2] = sumxy;
        mostrarMatrizEnTabla(mat);
        // no hay pasos Gauss para formula cerrada; limpiamos pasos
        pasosListModel.clear();
        pasosActuales = null;
    }

    // procesamiento regresion polinomial
    private void procesarPolinomial(double[][] puntos, int n) throws Exception {
        int m = puntos.length;
        int maxPow = 2*n;
        // construir cabeceras dinamicas similar PDF: xi yi xi^2 ... xi^(2n) yi*xi ... yi*xi^n
        java.util.Vector<String> headers = new java.util.Vector<>();
        headers.add("xi"); headers.add("yi");
        for (int p = 2; p <= maxPow; p++) headers.add("xi^" + p);
        for (int k = 1; k <= n; k++) headers.add("yi*xi^" + k);
        modelCalculos.setDataVector(new Object[0][0], headers.toArray());

        double[] sx = new double[2*n + 1];
        double[] sxy = new double[n + 1];
        for (int i = 0; i < sx.length; i++) sx[i] = 0;
        for (int i = 0; i < sxy.length; i++) sxy[i] = 0;

        for (int i = 0; i < m; i++) {
            double x = puntos[i][0], y = puntos[i][1];
            java.util.Vector<String> row = new java.util.Vector<>();
            row.add(df.format(x)); row.add(df.format(y));
            for (int p = 2; p <= maxPow; p++) {
                double val = Math.pow(x, p);
                row.add(df.format(val));
            }
            for (int k = 1; k <= n; k++) {
                double val = y * Math.pow(x, k);
                row.add(df.format(val));
            }
            modelCalculos.addRow(row.toArray());

            for (int j = 0; j <= maxPow; j++) sx[j] += Math.pow(x, j);
            for (int k = 0; k <= n; k++) sxy[k] += y * Math.pow(x, k);
        }
        // fila sumas (organizada coherentemente con headers)
        java.util.Vector<String> sumRow = new java.util.Vector<>();
        sumRow.add(df.format(sx[1])); // xi sum
        sumRow.add(df.format(sxy[0])); // yi sum (sxy[0])
        for (int p = 2; p <= maxPow; p++) sumRow.add(df.format(sx[p]));
        for (int k = 1; k <= n; k++) sumRow.add(df.format(sxy[k]));
        modelCalculos.addRow(sumRow.toArray());

        // crear matriz aumentada usando el metodo de RegresionMinCuad
        double[][] matriz = reg.creaMatrizSumatorias(sx, sxy, n);

        // mostrar matriz aumentada inicial
        mostrarMatrizEnTabla(matriz);

        // pedir a MetodosEcuaciones los pasos de Gauss-Jordan
        double[][] paraGauss = new double[matriz.length][matriz[0].length];
        for (int i = 0; i < matriz.length; i++) System.arraycopy(matriz[i], 0, paraGauss[i], 0, matriz[0].length);

        pasosActuales = MetodosEcuaciones.gaussJordanWithSteps(paraGauss);

        // llenar lista de pasos
        pasosListModel.clear();
        for (int i = 0; i < pasosActuales.size(); i++) {
            pasosListModel.addElement((i+1) + ". " + pasosActuales.get(i).descripcion);
        }
        // seleccionar primer paso para mostrar detalle
        if (!pasosActuales.isEmpty()) {
            listPasos.setSelectedIndex(0);
            mostrarMatrizEnTabla(pasosActuales.get(0).matriz);
        }

        // la ultima snapshot contiene la matriz reducida; extraer solucion
        GaussStep last = pasosActuales.get(pasosActuales.size() - 1);
        double[][] reducida = last.matriz;
        double[] coef = new double[reducida.length];
        for (int i = 0; i < reducida.length; i++) coef[i] = reducida[i][reducida[0].length - 1];

        // mostrar resultado
        StringBuilder sb = new StringBuilder("Polinomio grado " + n + ":\n");
        sb.append("y = ");
        for (int i = 0; i < coef.length; i++) {
            if (i > 0) sb.append(" + ");
            sb.append(df.format(coef[i]));
            if (i > 0) sb.append(" x^").append(i);
        }
        sb.append("\nCoeficientes:\n");
        for (int i = 0; i < coef.length; i++) sb.append("a").append(i).append(" = ").append(df.format(coef[i])).append("\n");
        txtResultado.setText(sb.toString());
    }

    // Multiple: crea matriz aumentada con RegresionMinCuad, pide pasos, muestra
    private void procesarMultiple(double[][] puntos) throws Exception {
        int n = puntos[0].length - 1;
        if (n < 1) throw new Exception("No hay variables independientes");

        double[][] matriz = reg.creaMatrizSumatoriasRLM(puntos);

        // mostrar matriz inicial
        mostrarMatrizEnTabla(matriz);

        // clonar y pedir pasos
        double[][] paraGauss = new double[matriz.length][matriz[0].length];
        for (int i = 0; i < matriz.length; i++) System.arraycopy(matriz[i], 0, paraGauss[i], 0, matriz[0].length);

        pasosActuales = MetodosEcuaciones.gaussJordanWithSteps(paraGauss);
        pasosListModel.clear();
        for (int i = 0; i < pasosActuales.size(); i++) pasosListModel.addElement((i+1) + ". " + pasosActuales.get(i).descripcion);
        if (!pasosActuales.isEmpty()) {
            listPasos.setSelectedIndex(0);
            mostrarMatrizEnTabla(pasosActuales.get(0).matriz);
        }

        GaussStep last = pasosActuales.get(pasosActuales.size() - 1);
        double[][] reducida = last.matriz;
        double[] coef = new double[reducida.length];
        for (int i = 0; i < reducida.length; i++) coef[i] = reducida[i][reducida[0].length - 1];

        StringBuilder sb = new StringBuilder("Regresion Lineal Multiple (n=" + n + ")\n");
        sb.append("y = ").append(df.format(coef[0]));
        for (int i = 1; i < coef.length; i++) sb.append(" + ").append(df.format(coef[i])).append(" x").append(i);
        sb.append("\nCoeficientes:\n");
        for (int i = 0; i < coef.length; i++) sb.append("a").append(i).append(" = ").append(df.format(coef[i])).append("\n");
        txtResultado.setText(sb.toString());
    }

    // mostrar matriz numerica en modelMatriz (con cabeceras genericas)
    private void mostrarMatrizEnTabla(double[][] matriz) {
        if (matriz == null || matriz.length == 0) {
            modelMatriz.setRowCount(0);
            modelMatriz.setColumnCount(0);
            return;
        }
        int cols = matriz[0].length;
        String[] headers = new String[cols];
        for (int j = 0; j < cols; j++) {
            headers[j] = (j == cols - 1) ? "b" : "c" + (j + 1); // c1..cn , b
        }
        modelMatriz.setDataVector(new Object[0][0], headers);
        for (int i = 0; i < matriz.length; i++) {
            Object[] row = new Object[cols];
            for (int j = 0; j < cols; j++) row[j] = df.format(matriz[i][j]);
            modelMatriz.addRow(row);
        }
        
    }
            //Ajusta el ancho de las columnas segun el contenido
        private void ajustarAnchoColumnas(JTable table) {
            table.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
            for (int column = 0; column < table.getColumnCount(); column++) {
                int width = 70; // ancho minimo base
                for (int row = 0; row < table.getRowCount(); row++) {
                    TableCellRenderer renderer = table.getCellRenderer(row, column);
                    Component comp = table.prepareRenderer(renderer, row, column);
                    width = Math.max(comp.getPreferredSize().width + 10, width);
                }
                table.getColumnModel().getColumn(column).setPreferredWidth(width);
            }
            table.setAutoResizeMode(JTable.AUTO_RESIZE_ALL_COLUMNS);
        }


    // MAIN
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new PruebaRegresionMinCuad());
    }
}
