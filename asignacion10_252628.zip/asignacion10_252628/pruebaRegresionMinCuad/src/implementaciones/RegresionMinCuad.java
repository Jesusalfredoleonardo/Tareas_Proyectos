package implementaciones;

import com.mycompany.gausssolver.MetodosEcuaciones;
import java.text.DecimalFormat;

/**
 * Clase que implementa metodos de regresion por minimos cuadrados.
 * Usa el metodo de Gauss-Jordan del proyecto GaussSolver para resolver los sistemas.
 */
public class RegresionMinCuad {

    // Formato decimal para mostrar valores con 6 cifras fijas
    private final DecimalFormat df = new DecimalFormat("0.000000");

    /**
     * Despliega una tabla con los puntos (x, y)
     * @param puntos arreglo de puntos donde cada fila contiene [x, y]
     */
    public void despliegaPuntos(double[][] puntos) {
        System.out.println("Tabla de puntos (x, y):");
        System.out.println("-------------------------");
        // recorre todas las filas (cada punto)
        for (double[] punto : puntos) {
            System.out.println("x = " + punto[0] + "   y = " + punto[1]);
        }
        System.out.println();
    }

    /**
     * Calcula los coeficientes del polinomio de grado n que ajusta los puntos.
     * @param puntos arreglo de puntos (x, y)
     * @param n grado del polinomio
     * @return arreglo con los coeficientes del polinomio
     */
    public double[] regresionPolinomial(double[][] puntos, int n) throws Exception {
        // arreglos para sumatorias
        double[] sx = new double[2 * n + 1];
        double[] sxy = new double[n + 1];

        // calcula las sumatorias necesarias
        creaSumatorias(puntos, sx, sxy, n);

        // crea la matriz aumentada del sistema normal
        double[][] matriz = creaMatrizSumatorias(sx, sxy, n);

        // resuelve el sistema con Gauss-Jordan y obtiene los coeficientes
        double[] coef = MetodosEcuaciones.gaussJordan(matriz);

        return coef;
    }

    /**
     * Calcula sumatorias de potencias de x y de productos y*x^i
     * @param puntos puntos (x, y)
     * @param sx arreglo para guardar sumatorias de x
     * @param sxy arreglo para guardar sumatorias de y*x^i
     * @param n grado del polinomio
     */
    public void creaSumatorias(double[][] puntos, double[] sx, double[] sxy, int n) {
        int m = puntos.length; // cantidad de puntos

        // inicializa todas las sumatorias en cero
        for (int i = 0; i < sx.length; i++) sx[i] = 0;
        for (int i = 0; i < sxy.length; i++) sxy[i] = 0;

        // recorre todos los puntos
        for (int i = 0; i < m; i++) {
            double x = puntos[i][0];
            double y = puntos[i][1];

            // suma potencias de x hasta 2n
            for (int j = 0; j <= 2 * n; j++) {
                sx[j] += Math.pow(x, j);
            }

            // suma productos y * x^k hasta n
            for (int k = 0; k <= n; k++) {
                sxy[k] += y * Math.pow(x, k);
            }
        }
    }

    /**
     * Genera la matriz aumentada del sistema normal para la regresion polinomial
     * @param sx sumatorias de potencias de x
     * @param sxy sumatorias de y*x^i
     * @param n grado del polinomio
     * @return matriz aumentada del sistema
     */
    public double[][] creaMatrizSumatorias(double[] sx, double[] sxy, int n) {
        double[][] matriz = new double[n + 1][n + 2];

        // llena la matriz con sumatorias segun el metodo de minimos cuadrados
        for (int i = 0; i <= n; i++) {
            for (int j = 0; j <= n; j++) {
                matriz[i][j] = sx[i + j];
            }
            matriz[i][n + 1] = sxy[i];
        }

        return matriz;
    }

    /**
     * Despliega el polinomio con sus coeficientes
     * @param a arreglo con los coeficientes del polinomio
     */
    public void despliegaPolinomio(double[] a) {
        System.out.println("Polinomio ajustado:");
        StringBuilder sb = new StringBuilder("y = ");
        // genera el texto del polinomio
        for (int i = 0; i < a.length; i++) {
            if (i > 0) sb.append(" + ");
            sb.append(df.format(a[i]));
            if (i > 0) sb.append("x^").append(i);
        }
        System.out.println(sb.toString());
        System.out.println();
    }

    /**
     * Despliega una tabla de puntos para la regresion lineal multiple
     * @param puntos matriz donde cada fila contiene las variables x1..xn y al final y
     */
    public void despliegaPuntosRLM(double[][] puntos) {
        System.out.println("Tabla de puntos para regresion lineal multiple:");
        System.out.println("----------------------------------------------");

        for (double[] fila : puntos) {
            for (int j = 0; j < fila.length; j++) {
                if (j < fila.length - 1)
                    System.out.print("x" + (j + 1) + "=" + fila[j] + "   ");
                else
                    System.out.print("y=" + fila[j]);
            }
            System.out.println();
        }
        System.out.println();
    }

    /**
     * Calcula los coeficientes de la regresion lineal multiple
     * @param puntos matriz con las variables independientes y la dependiente al final
     * @return arreglo con los coeficientes a0, a1, a2, ..., an
     */
    public double[] regresionLinealMultiple(double[][] puntos) throws Exception {
        // crea la matriz aumentada con las sumatorias
        double[][] matriz = creaMatrizSumatoriasRLM(puntos);

        // resuelve el sistema por Gauss-Jordan
        double[] coef = MetodosEcuaciones.gaussJordan(matriz);

        return coef;
    }

    /**
     * Crea la matriz aumentada para la regresion lineal multiple
     * @param puntos matriz donde cada fila contiene las variables x1..xn y y al final
     * @return matriz aumentada del sistema normal
     */
    public double[][] creaMatrizSumatoriasRLM(double[][] puntos) {
        int m = puntos.length; // numero de puntos
        int n = puntos[0].length - 1; // numero de variables independientes

        // la matriz sera de (n+1)x(n+2)
        double[][] M = new double[n + 1][n + 2];

        // primer elemento M[0][0] = numero de puntos
        M[0][0] = m;

        // sumatorias de xi y de productos xi*xj
        for (int i = 0; i < m; i++) {
            double[] fila = puntos[i];

            // sumatorias de xi
            for (int j = 0; j < n; j++) {
                M[0][j + 1] += fila[j];
                M[j + 1][0] += fila[j];
            }

            // productos xi*xj
            for (int j = 0; j < n; j++) {
                for (int k = 0; k < n; k++) {
                    M[j + 1][k + 1] += fila[j] * fila[k];
                }
            }

            // sumatorias de y
            double y = fila[n];
            M[0][n + 1] += y;
            for (int j = 0; j < n; j++) {
                M[j + 1][n + 1] += fila[j] * y;
            }
        }

        return M;
    }

    /**
     * Despliega la funcion lineal resultante de la regresion lineal multiple
     * @param a arreglo de coeficientes a0, a1, ..., an
     */
    public void despliegaFuncionLineal(double[] a) {
        System.out.println("Funcion lineal ajustada:");
        StringBuilder sb = new StringBuilder("y = ");
        sb.append(df.format(a[0]));
        for (int i = 1; i < a.length; i++) {
            sb.append(" + ").append(df.format(a[i])).append("x").append(i);
        }
        System.out.println(sb.toString());
        System.out.println();
    }
}
