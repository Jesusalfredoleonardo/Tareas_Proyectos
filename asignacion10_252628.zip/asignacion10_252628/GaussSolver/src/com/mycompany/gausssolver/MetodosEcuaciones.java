package com.mycompany.gausssolver;

import java.util.ArrayList;
import java.util.List;

/**
 * MetodosEcuaciones
 * Metodos numericos reutilizables. Incluye Gauss-Jordan y una version que
 * devuelve pasos (snapshots) de la matriz aumentada durante el proceso.
 */
public class MetodosEcuaciones {

    /**
     * Contenedor de paso de Gauss: descripcion y snapshot de la matriz.
     */
    public static class GaussStep {
        public final String descripcion;
        public final double[][] matriz; // copia inmutable del estado

        public GaussStep(String descripcion, double[][] matriz) {
            this.descripcion = descripcion;
            // clon profundo de la matriz para evitar aliasing
            this.matriz = new double[matriz.length][matriz[0].length];
            for (int i = 0; i < matriz.length; i++) {
                System.arraycopy(matriz[i], 0, this.matriz[i], 0, matriz[i].length);
            }
        }
    }

    /**
     * Gauss-Jordan que devuelve solo el vector solucion (compatibilidad).
     * Nota: modifica la matriz A in-place.
     * @param A matriz aumentada n x (n+1)
     * @return vector solucion
     * @throws Exception si pivote cercano a cero
     */
    public static double[] gaussJordan(double[][] A) throws Exception {
        int n = A.length;
        int m = A[0].length;

        for (int k = 0; k < n; k++) {
            int pivotRow = k;
            double max = Math.abs(A[k][k]);
            for (int i = k + 1; i < n; i++) {
                if (Math.abs(A[i][k]) > max) {
                    max = Math.abs(A[i][k]);
                    pivotRow = i;
                }
            }
            if (Math.abs(max) < 1e-14) throw new Exception("Pivote casi cero en columna " + (k + 1));

            if (pivotRow != k) {
                double[] tmp = A[k];
                A[k] = A[pivotRow];
                A[pivotRow] = tmp;
            }

            double pivot = A[k][k];
            for (int j = k; j < m; j++) A[k][j] /= pivot;

            for (int i = 0; i < n; i++) {
                if (i == k) continue;
                double factor = A[i][k];
                for (int j = k; j < m; j++) {
                    A[i][j] -= factor * A[k][j];
                }
            }
        }

        double[] x = new double[n];
        for (int i = 0; i < n; i++) x[i] = A[i][m - 1];
        return x;
    }

    /**
     * Gauss-Jordan que registra pasos y snapshots de la matriz.
     * Devuelve una lista de GaussStep en orden cronologico:
     * - paso inicial (descripcion "Inicial")
     * - cada intercambio de filas ("Intercambiar Rx <-> Ry")
     * - cada normalizacion de fila ("Normalizar Rk / pivot")
     * - cada eliminacion ("R i = R i - factor * R k")
     * - paso final con descripcion "Resultado"
     *
     * Nota: la matriz pasada si se modifica in-place durante la ejecucion;
     * se devuelve una lista con copias de estado en cada paso.
     *
     * @param A matriz aumentada n x (n+1)
     * @return lista de pasos (GaussStep)
     * @throws Exception si pivote casi cero
     */
    public static List<GaussStep> gaussJordanWithSteps(double[][] A) throws Exception {
        int n = A.length;
        int m = A[0].length;
        List<GaussStep> pasos = new ArrayList<>();

        // paso inicial
        pasos.add(new GaussStep("Inicial", A));

        for (int k = 0; k < n; k++) {
            // pivoteo parcial
            int pivotRow = k;
            double max = Math.abs(A[k][k]);
            for (int i = k + 1; i < n; i++) {
                if (Math.abs(A[i][k]) > max) {
                    max = Math.abs(A[i][k]);
                    pivotRow = i;
                }
            }
            if (Math.abs(max) < 1e-14) throw new Exception("Pivote casi cero en columna " + (k + 1));

            // intercambio si necesario
            if (pivotRow != k) {
                double[] tmp = A[k];
                A[k] = A[pivotRow];
                A[pivotRow] = tmp;
                pasos.add(new GaussStep("Intercambio R" + (k+1) + " <-> R" + (pivotRow+1), A));
            }

            // normalizar fila pivote
            double pivot = A[k][k];
            for (int j = k; j < m; j++) A[k][j] /= pivot;
            pasos.add(new GaussStep("Normalizar R" + (k+1) + " / " + pivot, A));

            // eliminar otras filas
            for (int i = 0; i < n; i++) {
                if (i == k) continue;
                double factor = A[i][k];
                for (int j = k; j < m; j++) {
                    A[i][j] -= factor * A[k][j];
                }
                pasos.add(new GaussStep("R" + (i+1) + " = R" + (i+1) + " - " + factor + " * R" + (k+1), A));
            }
        }

        // paso resultado final (matriz en forma reducida)
        pasos.add(new GaussStep("Resultado (matriz reducida)", A));

        return pasos;
    }
}
