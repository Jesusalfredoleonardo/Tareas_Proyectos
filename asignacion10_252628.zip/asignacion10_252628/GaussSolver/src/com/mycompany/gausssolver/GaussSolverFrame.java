package com.mycompany.gausssolver;

import javax.swing.*;
import javax.swing.event.ChangeEvent;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableCellRenderer;
import javax.swing.table.TableColumn;
import java.awt.*;
import java.text.DecimalFormat;

/**
 * GaussSolverFrame - Version mejorada:
 * - Tabla de entrada ajusta columnas segun tamaño de numeros.
 * - Tabla de pasos muestra texto envuelto (sin '...') y ajusta alto de filas.
 * - Frame de tamaño fijo (no redimensionable).
 */
public class GaussSolverFrame extends JFrame {
    private JTable tableInput, tableSteps;
    private DefaultTableModel modelInput, modelSteps;
    private JButton btnGauss, btnGaussJordan, btnClear;
    private JSpinner spSize, spDecimals;
    private DecimalFormat df;

    public GaussSolverFrame() {
        initComponents();
    }

    private void initComponents() {
        setTitle("Metodo de Gauss y Gauss-Jordan - Interfaz Mejorada");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setSize(1100, 750);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout(12, 12));

        // PANEL SUPERIOR
        JPanel topPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 14, 12));
        btnGauss = new JButton("Resolver con Gauss");
        btnGaussJordan = new JButton("Resolver con Gauss-Jordan");
        btnClear = new JButton("Limpiar");

        topPanel.add(btnGauss);
        topPanel.add(btnGaussJordan);
        topPanel.add(btnClear);

        topPanel.add(new JLabel("Ecuaciones:"));
        spSize = new JSpinner(new SpinnerNumberModel(3, 2, 10, 1));
        topPanel.add(spSize);

        topPanel.add(new JLabel("Decimales:"));
        spDecimals = new JSpinner(new SpinnerNumberModel(4, 0, 10, 1));
        topPanel.add(spDecimals);

        add(topPanel, BorderLayout.NORTH);

        // TABLA DE ENTRADA
        modelInput = new DefaultTableModel();
        tableInput = new JTable(modelInput);
        tableInput.setFont(new Font("SansSerif", Font.PLAIN, 14));
        tableInput.setRowHeight(26);

        // TABLA DE RESULTADOS (no editable)
        String[] colSteps = {"Paso", "Operacion", "Fila modificada", "Resultado (completo)"};
        modelSteps = new DefaultTableModel(colSteps, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false; // tabla de resultado no editable
            }
        };
        tableSteps = new JTable(modelSteps);
        tableSteps.setFont(new Font("Monospaced", Font.PLAIN, 13));
        tableSteps.setRowHeight(26);

        // El renderer para la columna "Resultado" usa JTextArea para wrap y multiple lines
        TextAreaRenderer wrapRenderer = new TextAreaRenderer();
        tableSteps.getColumnModel().getColumn(3).setCellRenderer(wrapRenderer);
        tableSteps.setShowGrid(true);
        tableSteps.setAutoResizeMode(JTable.AUTO_RESIZE_OFF); // permitimos scroll horizontal si es necesario

        // Panel central con ambas tablas (una encima de otra)
        JScrollPane spInput = new JScrollPane(tableInput);
        spInput.setBorder(BorderFactory.createTitledBorder("Matriz aumentada (entrada manual)"));
        spInput.setPreferredSize(new Dimension(1060, 260));

        JScrollPane spSteps = new JScrollPane(tableSteps);
        spSteps.setBorder(BorderFactory.createTitledBorder("Resultados y operaciones paso a paso"));
        spSteps.setPreferredSize(new Dimension(1060, 360));

        JPanel centerPanel = new JPanel();
        centerPanel.setLayout(new BoxLayout(centerPanel, BoxLayout.Y_AXIS));
        centerPanel.setBorder(BorderFactory.createEmptyBorder(6, 12, 12, 12));
        centerPanel.add(spInput);
        centerPanel.add(Box.createRigidArea(new Dimension(0, 10)));
        centerPanel.add(spSteps);

        add(centerPanel, BorderLayout.CENTER);

        // EVENTOS
        spSize.addChangeListener((ChangeEvent e) -> {
            updateMatrixSize();
        });
        spDecimals.addChangeListener((ChangeEvent e) -> updateDecimalFormat());
        btnGauss.addActionListener(e -> doGauss());
        btnGaussJordan.addActionListener(e -> doGaussJordan());
        btnClear.addActionListener(e -> clearAll());

        // Inicializar formato decimal y tabla
        updateDecimalFormat();
        updateMatrixSize();

        // Mantener el frame con tamaño fijo (no redimensionable)
        setResizable(false);
    }

    // Actualiza formato decimal
    private void updateDecimalFormat() {
        int dec = (Integer) spDecimals.getValue();
        String pattern = (dec <= 0) ? "0" : "0." + "0".repeat(dec);
        df = new DecimalFormat(pattern);
    }

    // Actualiza tamaño de la matriz (n x n+1) y rellena con ceros
    private void updateMatrixSize() {
        int n = (Integer) spSize.getValue();
        String[] cols = new String[n + 1];
        for (int i = 0; i < n; i++) cols[i] = "x" + (i + 1);
        cols[n] = "b";

        Object[][] data = new Object[n][n + 1];
        for (int i = 0; i < n; i++)
            for (int j = 0; j < n + 1; j++)
                data[i][j] = "0";

        modelInput.setDataVector(data, cols);

        // ajustar anchos de columnas en tabla de entrada segun contenido
        SwingUtilities.invokeLater(() -> adjustInputColumnWidths());
    }

    // Ajusta los anchos de columna de la tabla de entrada para evitar espacios sobrantes
    private void adjustInputColumnWidths() {
        tableInput.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
        FontMetrics fm = tableInput.getFontMetrics(tableInput.getFont());
        int cols = tableInput.getColumnCount();

        int totalWidth = 0;
        for (int c = 0; c < cols; c++) {
            TableColumn col = tableInput.getColumnModel().getColumn(c);
            // medir header
            int maxW = fm.stringWidth(col.getHeaderValue().toString()) + 18;
            // medir contenido
            for (int r = 0; r < tableInput.getRowCount(); r++) {
                Object val = tableInput.getValueAt(r, c);
                if (val != null) {
                    int w = fm.stringWidth(val.toString()) + 18;
                    if (w > maxW) maxW = w;
                }
            }
            // Limitar anchura minima y maxima
            int min = 50;
            int maxAllowed = 180;
            int preferred = Math.max(min, Math.min(maxW, maxAllowed));
            col.setPreferredWidth(preferred);
            totalWidth += preferred;
        }
        // si sobra mucho espacio, simplemente centrar la tabla en su scrollpane (ya lo hace)
    }

    // Limpia ambas tablas (reinicia datos y pasos)
    private void clearAll() {
        updateMatrixSize();
        modelSteps.setRowCount(0);
    }

    // Lee la matriz desde la tabla de entrada y la devuelve como double[][]
    private double[][] getMatrixFromTable() throws Exception {
        int rows = modelInput.getRowCount();
        int cols = modelInput.getColumnCount();
        double[][] A = new double[rows][cols];
        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < cols; j++) {
                Object val = modelInput.getValueAt(i, j);
                if (val == null || val.toString().trim().isEmpty())
                    throw new Exception("Celda vacia en fila " + (i + 1) + ", columna " + (j + 1) + ". Por favor escriba un numero.");
                try {
                    A[i][j] = Double.parseDouble(val.toString().trim());
                } catch (NumberFormatException ex) {
                    throw new Exception("Valor invalido en fila " + (i + 1) + ", columna " + (j + 1) + ". Use solo numeros.");
                }
            }
        }
        return A;
    }

    // Ejecuta Gauss y rellena tablaSteps con pasos tabulados
    private void doGauss() {
        try {
            modelSteps.setRowCount(0);
            updateDecimalFormat();
            double[][] A = getMatrixFromTable();
            gaussEliminationWithSteps(A);
            adjustStepsColumnWidthsAndHeights();
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    // Ejecuta Gauss-Jordan y rellena tablaSteps con pasos tabulados
    private void doGaussJordan() {
        try {
            modelSteps.setRowCount(0);
            updateDecimalFormat();
            double[][] A = getMatrixFromTable();
            gaussJordanWithSteps(A);
            adjustStepsColumnWidthsAndHeights();
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    //GAUSS (DETALLADO)
    private void gaussEliminationWithSteps(double[][] A) throws Exception {
        int n = A.length;
        int m = A[0].length;

        for (int k = 0; k < n - 1; k++) {
            // pivoteo parcial
            int pivotRow = k;
            double max = Math.abs(A[k][k]);
            for (int i = k + 1; i < n; i++) {
                if (Math.abs(A[i][k]) > max) {
                    max = Math.abs(A[i][k]);
                    pivotRow = i;
                }
            }
            if (Math.abs(max) < 1e-14) throw new Exception("Pivote casi cero en columna " + (k + 1) + ". El sistema puede ser singular.");

            if (pivotRow != k) {
                swapRows(A, k, pivotRow);
                modelSteps.addRow(new Object[]{
                        "Pivoteo",
                        "Intercambiar R" + (k + 1) + " <-> R" + (pivotRow + 1),
                        "-",
                        matrixToString(A)
                });
            }

            for (int i = k + 1; i < n; i++) {
                double factor = A[i][k] / A[k][k];
                for (int j = k; j < m; j++) A[i][j] -= factor * A[k][j];
                modelSteps.addRow(new Object[]{
                        "Eliminacion",
                        "m" + (i + 1) + (k + 1) + " = " + df.format(factor),
                        "R" + (i + 1),
                        rowToString(A[i])
                });
            }
        }

        // sustitucion hacia atras
        double[] x = new double[n];
        for (int i = n - 1; i >= 0; i--) {
            double sum = A[i][m - 1];
            for (int j = i + 1; j < n; j++) sum -= A[i][j] * x[j];
            x[i] = sum / A[i][i];
        }
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < n; i++) sb.append("x").append(i + 1).append("=").append(df.format(x[i])).append("  ");
        modelSteps.addRow(new Object[]{"Resultado", "-", "-", sb.toString()});
    }

    //GAUSS-JORDAN (DETALLADO)
    private void gaussJordanWithSteps(double[][] A) throws Exception {
        int n = A.length;
        int m = A[0].length;

        for (int k = 0; k < n; k++) {
            // pivoteo parcial
            int pivotRow = k;
            double max = Math.abs(A[k][k]);
            for (int i = k + 1; i < n; i++) {
                if (Math.abs(A[i][k]) > max) {
                    max = Math.abs(A[i][k]);
                    pivotRow = i;
                }
            }
            if (Math.abs(max) < 1e-14) throw new Exception("Pivote casi cero en columna " + (k + 1) + ". El sistema puede ser singular.");

            if (pivotRow != k) {
                swapRows(A, k, pivotRow);
                modelSteps.addRow(new Object[]{"Pivoteo", "Intercambiar R" + (k + 1) + " <-> R" + (pivotRow + 1), "-", matrixToString(A)});
            }

            double pivot = A[k][k];
            // normalizar fila k
            for (int j = k; j < m; j++) A[k][j] /= pivot;
            modelSteps.addRow(new Object[]{"Normalizar", "R" + (k + 1) + " / " + df.format(pivot), "R" + (k + 1), rowToString(A[k])});

            // eliminar otras filas
            for (int i = 0; i < n; i++) {
                if (i == k) continue;
                double factor = A[i][k];
                for (int j = k; j < m; j++) A[i][j] -= factor * A[k][j];
                modelSteps.addRow(new Object[]{
                        "Eliminacion",
                        "m" + (i + 1) + (k + 1) + " = " + df.format(factor),
                        "R" + (i + 1),
                        rowToString(A[i])
                });
            }
        }

        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < n; i++) sb.append("x").append(i + 1).append("=").append(df.format(A[i][m - 1])).append("  ");
        modelSteps.addRow(new Object[]{"Resultado", "-", "-", sb.toString()});
    }

    // Ajusta las columnas y alturas de la tabla de pasos para que el contenido se vea completo
    private void adjustStepsColumnWidthsAndHeights() {
        tableSteps.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
        FontMetrics fm = tableSteps.getFontMetrics(tableSteps.getFont());
        int cols = tableSteps.getColumnCount();

        // calcular ancho preferido por columna (header y contenido)
        for (int c = 0; c < cols; c++) {
            TableColumn col = tableSteps.getColumnModel().getColumn(c);
            int maxW = fm.stringWidth(col.getHeaderValue().toString()) + 18;
            for (int r = 0; r < tableSteps.getRowCount(); r++) {
                Object val = tableSteps.getValueAt(r, c);
                if (val != null) {
                    // para la columna resultado permitimos un ancho mayor razonable
                    int w = fm.stringWidth(val.toString()) + 18;
                    if (w > maxW) maxW = w;
                }
            }
            // limites practicos
            int min = 80;
            int maxAllowed = (c == 3) ? 600 : 280; // columna resultado puede ser mas ancha
            int preferred = Math.max(min, Math.min(maxW, maxAllowed));
            col.setPreferredWidth(preferred);
        }

        // Ajustar alto por fila segun la columna que use wrap (la 3)
        adjustRowHeights(tableSteps);
    }

    // Ajusta la altura de cada fila de la tabla segun el renderer (para celdas multiline)
    private void adjustRowHeights(JTable table) {
        for (int row = 0; row < table.getRowCount(); row++) {
            int maxHeight = 1;
            for (int column = 0; column < table.getColumnCount(); column++) {
                TableCellRenderer renderer = table.getCellRenderer(row, column);
                Component comp = renderer.getTableCellRendererComponent(table,
                        table.getValueAt(row, column), false, false, row, column);
                int h = comp.getPreferredSize().height;
                maxHeight = Math.max(maxHeight, h);
            }
            if (table.getRowHeight(row) != maxHeight) {
                table.setRowHeight(row, maxHeight);
            }
        }
    }

    private void swapRows(double[][] A, int r1, int r2) {
        double[] tmp = A[r1];
        A[r1] = A[r2];
        A[r2] = tmp;
    }

    private String matrixToString(double[][] A) {
        StringBuilder sb = new StringBuilder();
        for (double[] fila : A) {
            sb.append("[");
            for (int j = 0; j < fila.length; j++) {
                sb.append(df.format(fila[j]));
                if (j < fila.length - 1) sb.append(", ");
            }
            sb.append("] ");
        }
        return sb.toString();
    }

    private String rowToString(double[] fila) {
        StringBuilder sb = new StringBuilder("[ ");
        for (int j = 0; j < fila.length; j++) {
            sb.append(df.format(fila[j]));
            if (j < fila.length - 1) sb.append(", ");
        }
        sb.append(" ]");
        return sb.toString();
    }

    // Renderer que permite wrap en celdas (usa JTextArea)
    static class TextAreaRenderer extends JTextArea implements TableCellRenderer {
        public TextAreaRenderer() {
            setLineWrap(true);
            setWrapStyleWord(true);
            setOpaque(true);
        }

        @Override
        public Component getTableCellRendererComponent(JTable table, Object value,
                                                       boolean isSelected, boolean hasFocus,
                                                       int row, int column) {
            setText(value == null ? "" : value.toString());
            setFont(table.getFont());
            setBorder(null);
            // Ajustar ancho para calcular preferredSize correctamente
            int colWidth = table.getColumnModel().getColumn(column).getWidth();
            setSize(new Dimension(colWidth, Short.MAX_VALUE));
            return this;
        }
    }

    // MAIN
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            GaussSolverFrame frame = new GaussSolverFrame();
            frame.setVisible(true);
        });
    }
}
