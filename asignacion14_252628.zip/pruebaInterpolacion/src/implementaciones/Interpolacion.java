package implementaciones;

/**
 * Clase que implementa el metodo de interpolacion de Lagrange.
 * Contiene metodos para desplegar puntos, calcular la multiplicatoria
 * y evaluar el polinomio de Lagrange en una abscisa x.
 *
 * @author PC EXPRESS NAVOJOA
 */
public class Interpolacion {

    /**
     * Despliega una tabla con los n+1 puntos contenidos en el arreglo puntos.
     * Cada fila: x  y
     *
     * @param puntos arreglo bidimensional con n+1 filas y 2 columnas:
     *               puntos[i][0] = xi, puntos[i][1] = yi
     * @param n grado del polinomio (n)
     */
    public void despliegaPuntos(double puntos[][], int n) {
        int filas = n + 1;
        System.out.println("+----------------------+");
        System.out.printf("|  Grado n = %d         |\n", n);
        System.out.println("+----------------------+");
        System.out.printf("%8s %16s\n", "x", "y");
        System.out.println("------------------------");
        for (int i = 0; i < filas; i++) {
            System.out.printf("%8.6f %16.6f\n", puntos[i][0], puntos[i][1]);
        }
        System.out.println("------------------------");
    }

    /**
     * Calcula la multiplicatoria del termino i en el metodo de Lagrange:
     * L_i(x) = prod_{j != i} (x - x_j) / (x_i - x_j)
     *
     * @param i indice del termino (0..n)
     * @param puntos arreglo bidimensional con n+1 filas y 2 columnas
     * @param n grado del polinomio
     * @param x abscisa donde evaluar la multiplicatoria
     * @return valor de la multiplicatoria L_i(x)
     */
    public double multiplicatoria(int i, double puntos[][], int n, double x) {
        int filas = n + 1;
        double xi = puntos[i][0];
        double producto = 1.0;
        for (int j = 0; j < filas; j++) {
            if (j == i) continue;
            double xj = puntos[j][0];
            producto *= (x - xj) / (xi - xj);
        }
        return producto;
    }

    /**
     * Interpola usando el metodo de Lagrange de grado n los puntos contenidos en puntos
     * y evalua el polinomio en la abscisa x.
     *
     * @param puntos arreglo bidimensional con n+1 filas y 2 columnas
     * @param n grado del polinomio
     * @param x abscisa donde evaluar el polinomio
     * @return ordenada interpolada f(x)
     */
    public double interpolacionLagrange(double puntos[][], int n, double x) {
        int filas = n + 1;
        double resultado = 0.0;
        for (int i = 0; i < filas; i++) {
            double yi = puntos[i][1];
            double Li = multiplicatoria(i, puntos, n, x);
            resultado += yi * Li;
        }
        return resultado;
    }
}
