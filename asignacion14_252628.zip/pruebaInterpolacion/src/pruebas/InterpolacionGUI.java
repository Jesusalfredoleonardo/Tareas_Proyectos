package pruebas;

import javax.swing.*;
import javax.swing.border.TitledBorder;
import javax.swing.table.*;
import javax.swing.text.*;
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;

/**
 * InterpolacionGUI
 * Ventana grafica que permite calcular la interpolacion de Lagrange
 * usando una tabla de puntos y mostrando el procedimiento en HTML.
 * Esta clase crea la interfaz, los componentes y controla todo el flujo.
 * @author PC EXPRESS NAVOJOA
 */
public class InterpolacionGUI extends JFrame {

    // Tabla donde se colocan los datos x,y
    private JTable table;

    // Modelo de la tabla (maneja filas y columnas)
    private DefaultTableModel model;

    // Spinner para elegir el grado de interpolacion
    private JSpinner spGrado;

    // Campo donde el usuario escribe el punto a evaluar
    private JTextField txtXeval;

    // Panel HTML que mostrara los pasos de la interpolacion
    private JEditorPane htmlSteps;

    // Label donde se muestra el resultado final en grande
    private JLabel lblResultado;

    /**
     * Constructor principal.
     * Inicializa la ventana y los componentes.
     */
    public InterpolacionGUI() {

        // Titulo de la ventana
        setTitle("Interpolacion de Lagrange - GUI");

        // Cierra la app al cerrar la ventana
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        // No deja que el usuario cambie el tamano manualmente
        setResizable(false);

        // Tamano de la ventana
        setSize(1100, 600);

        // Centrar la ventana en la pantalla
        setLocationRelativeTo(null);

        // Llamamos el metodo que construye toda la interfaz
        initUI();
        

        // Hacer visible la ventana
        setVisible(true);
    }

    /**
     * Metodo que crea la interfaz grafica completa.
     * Aqui se construyen paneles, botones, tabla, area HTML, etc.
     */
    private void initUI() {

        // PANEL SUPERIOR (controles: grado, x a evaluar, botones)

        // Panel horizontal para controles
        JPanel topPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
           
        // JComboBox para ejercicios predefinidos
        String[] ejercicios = {
                "Seleccione un ejercicio...",
                "Ejercicio 1: Lineal (x={3,5})",
                "Ejercicio 2: Cuadrático (x={2,3,5})",
                "Ejercicio 3: Cúbico (x={2,3,5,6})"
        };

        JComboBox<String> cbEjercicios = new JComboBox<>(ejercicios);
        cbEjercicios.setPreferredSize(new Dimension(250, 28));

        // Evento del ComboBox
        cbEjercicios.addActionListener(e -> {

            int index = cbEjercicios.getSelectedIndex();

            // Nada seleccionado
            if (index == 0) return;

            // Datos segun el ejercicio
            double[] X, Y;
            int grado = 1;

            switch (index) {

                case 1: // Ejercicio 1 lineal
                    grado = 1;
                    X = new double[]{3, 5};
                    Y = new double[]{5.25, 19.75};
                    break;

                case 2: // Ejercicio 2 cuadrático
                    grado = 2;
                    X = new double[]{2, 3, 5};
                    Y = new double[]{4, 5.25, 19.75};
                    break;

                case 3: // Ejercicio 3 cúbico
                    grado = 3;
                    X = new double[]{2, 3, 5, 6};
                    Y = new double[]{4, 5.25, 19.75, 36};
                    break;

                default:
                    return;
            }

            // Actualiza el spinner del grado
            spGrado.setValue(grado);

            // Genera la tabla del tamaño correcto
            generarTabla();

            // Llena la tabla con los datos
            for (int i = 0; i < X.length; i++) {
                table.setValueAt(X[i], i, 0);
                table.setValueAt(Y[i], i, 1);
            }

            ajustarColumnas();
        });

        
        // Espaciado interno del panel
        topPanel.setBorder(BorderFactory.createEmptyBorder(6, 6, 6, 6));

        // Spinner: grado de interpolacion (1, 2 o 3)
        spGrado = new JSpinner(new SpinnerNumberModel(1, 1, 3, 1));

        // Campo para ingresar el valor donde se evalua f(x)
        txtXeval = new JTextField("3.5", 6);

        // Boton para generar la tabla
        JButton btnTabla = blueButton("Generar tabla");

        // Boton para calcular la interpolacion
        JButton btnCalcular = blueButton("Calcular");

        // Acciones que ejecutan los botones
        btnTabla.addActionListener(e -> generarTabla());
        btnCalcular.addActionListener(e -> calcular());

        // Agregando componentes al panel superior
        topPanel.add(new JLabel("Grado n: "));
        topPanel.add(spGrado);
        topPanel.add(new JLabel(" Ejercicios: "));
        topPanel.add(cbEjercicios);
        topPanel.add(new JLabel("  Evaluar en x: "));
        topPanel.add(txtXeval);
        topPanel.add(btnTabla);
        topPanel.add(btnCalcular);

        // Colocamos el panel superior en la parte de arriba del JFrame
        getContentPane().add(topPanel, BorderLayout.NORTH);
    
               
        // TABLA

        // Crea el modelo vacio de la tabla (sin filas ni columnas)
        model = new DefaultTableModel();

        // Crea la tabla visual usando el modelo anterior
        table = new JTable(model);

        // Fuente usada en las celdas de la tabla
        table.setFont(new Font("SansSerif", Font.PLAIN, 15));

        // Altura de cada fila
        table.setRowHeight(28);

        // Muestra las lineas de la cuadricula
        table.setShowGrid(true);

        // Color gris claro para la cuadricula
        table.setGridColor(new Color(180, 180, 180));

        // La tabla debe ir dentro de un ScrollPane para poder desplazarse
        JScrollPane spTable = new JScrollPane(table);

        // Pone un borde con titulo "Tabla (x, y)"
        spTable.setBorder(BorderFactory.createTitledBorder("Tabla (x, y)"));

        
        // AREA DE PASOS (HTML)

        // Crea un panel HTML donde se mostrara el procedimiento paso a paso
        htmlSteps = new JEditorPane("text/html", "");

        // No permite que el usuario edite el contenido
        htmlSteps.setEditable(false);

        // Hace que el JEditorPane respete las fuentes declaradas
        htmlSteps.putClientProperty(JEditorPane.HONOR_DISPLAY_PROPERTIES, Boolean.TRUE);

        // Asigna la fuente Consolas para que parezca codigo
        htmlSteps.setFont(new Font("Consolas", Font.PLAIN, 14));

        // Scroll para mover el area HTML
        JScrollPane spSteps = new JScrollPane(htmlSteps);

        // Define un tamano preferido para este panel
        spSteps.setPreferredSize(new Dimension(400, 500));

        // Pone un borde con titulo "Procedimiento detallado"
        spSteps.setBorder(new TitledBorder("Procedimiento detallado"));

        
        // RESULTADO

        // Label superior que mostrara el resultado final
        lblResultado = new JLabel("Resultado de f(x)= ---");

        // Centra el texto dentro del label
        lblResultado.setHorizontalAlignment(SwingConstants.CENTER);

        // Fuente mas grande para que resalte
        lblResultado.setFont(new Font("SansSerif", Font.BOLD, 18));

        // El texto principal del label sera negro
        lblResultado.setForeground(Color.BLACK);

        // Coloca este label como encabezado del area HTML
        spSteps.setColumnHeaderView(lblResultado);

        // SPLIT PANEL (DIVIDE TABLA Y PASOS)

        // Panel que divide la ventana en dos partes: izquierda tabla, derecha pasos
        JSplitPane split = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, spTable, spSteps);

        // Define la posicion inicial del divisor
        split.setDividerLocation(600);

        // Agrega este panel dividido al centro de la ventana
        getContentPane().add(split, BorderLayout.CENTER);
    }

    // Generar Tabla

    /**
     * Genera la tabla segun el grado seleccionado.
     * Si el grado es n, se crean n+1 filas para los puntos (x,y).
     * Tambien coloca el filtro numerico y ajusta el ancho de columnas.
     */
    private void generarTabla() {

        // Obtiene el grado seleccionado en el spinner
        int n = (int) spGrado.getValue();

        // El numero de filas es n + 1 (porque se necesitan n+1 puntos)
        int filas = n + 1;

        // Arreglo bidimensional para los valores de la tabla
        Object[][] data = new Object[filas][2];

        // Llenamos con cadenas vacias al inicio
        for (int i = 0; i < filas; i++) {
            data[i][0] = ""; // columna x
            data[i][1] = ""; // columna y
        }

        // Asigna los datos y los titulos de columna al modelo
        model.setDataVector(data, new String[]{"x", "y"});

        // Aplica el filtro numerico a las celdas
        aplicarFiltroNumerico();

        // Ajusta el ancho de columnas
        ajustarColumnas();
    }

    // Filtro numerico decimal

    /**
     * Aplica un filtro para que las celdas solo acepten numeros decimales.
     * Cada columna de la tabla obtiene un editor personalizado.
     */
    private void aplicarFiltroNumerico() {

        // Recorre todas las columnas de la tabla
        for (int i = 0; i < table.getColumnCount(); i++) {

            // Campo de texto que servira como editor de celda
            JTextField tf = new JTextField();

            // Colocamos un DocumentFilter que valida numeros decimales
            ((AbstractDocument) tf.getDocument())
                    .setDocumentFilter(new NumericFilter());

            // Asignamos el editor a la columna actual
            table.getColumnModel().getColumn(i)
                    .setCellEditor(new DefaultCellEditor(tf));

            // Cuando el usuario sale de la celda, ajustamos el ancho
            tf.addFocusListener(new FocusAdapter() {
                @Override
                public void focusLost(FocusEvent e) {
                    ajustarColumnas();
                }
            });
        }
    }

    // Ajuste verdadero de columnas

    /**
     * Ajusta automaticamente el ancho de cada columna segun su contenido.
     * Mide el ancho del header y de cada celda para calcular el maximo.
     */
    private void ajustarColumnas() {

        // Evita el auto-redimensionamiento automatico de JTable
        table.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);

        // Recorremos todas las columnas
        for (int c = 0; c < table.getColumnCount(); c++) {

            // Columna actual
            TableColumn col = table.getColumnModel().getColumn(c);

            // Ancho minimo que se quiere mantener
            int maxWidth = 60;

            // Medimos el ancho del header de la columna
            TableCellRenderer headerRenderer = table.getTableHeader().getDefaultRenderer();

            Component compHeader = headerRenderer.getTableCellRendererComponent(
                    table, col.getHeaderValue(), false, false, -1, c);

            // Tomamos el mayor entre el valor actual y el ancho calculado
            maxWidth = Math.max(maxWidth, compHeader.getPreferredSize().width + 10);

            // Medimos el ancho de todas las celdas de la columna
            for (int r = 0; r < table.getRowCount(); r++) {

                // Render para la celda actual
                TableCellRenderer renderer = table.getCellRenderer(r, c);

                Component comp = renderer.getTableCellRendererComponent(
                        table, table.getValueAt(r, c), false, false, r, c);

                // Ancho recomendado de la celda
                int width = comp.getPreferredSize().width + 15;

                // Nos quedamos con el mayor de todos
                maxWidth = Math.max(maxWidth, width);
            }

            // Finalmente aplicamos el ancho calculado a la columna
            col.setPreferredWidth(maxWidth);
        }
    }

    // Calculo de Lagrange con HTML (pasos simples)

    /**
     * Metodo que realiza el calculo de interpolacion de Lagrange.
     * Toma los valores x,y ingresados en la tabla, evalua el punto deseado
     * y genera un reporte HTML con:
     * 1) Formula general
     * 2) Sustitucion numerica
     * 3) Evaluacion de cada termino
     * 4) Resultado final de f(x)
     */
    private void calcular() {

        try {

            // Obtiene el grado de interpolacion elegido
            int n = (int) spGrado.getValue();

            // Valor de x donde se evaluara f(x)
            double xEval = Double.parseDouble(txtXeval.getText());

            // Listas que guardan los valores X y Y de la tabla
            ArrayList<Double> X = new ArrayList<>();
            ArrayList<Double> Y = new ArrayList<>();

            // Obtiene los datos de la tabla y valida que no haya vacios
            for (int i = 0; i < model.getRowCount(); i++) {

                // Verifica que no haya celdas vacias
                if (table.getValueAt(i, 0) == null || table.getValueAt(i, 1) == null
                        || table.getValueAt(i, 0).toString().isEmpty()
                        || table.getValueAt(i, 1).toString().isEmpty()) {

                    JOptionPane.showMessageDialog(this,
                            "No puede haber celdas vacias",
                            "Error", JOptionPane.WARNING_MESSAGE);
                    return;
                }

                // Agrega los valores convertidos a double
                X.add(Double.parseDouble(model.getValueAt(i, 0).toString()));
                Y.add(Double.parseDouble(model.getValueAt(i, 1).toString()));
            }

            // Construccion del HTML donde se mostrara todo el procedimiento
            StringBuilder html = new StringBuilder();

            // Inicio del cuerpo HTML
            html.append("<html><body style='font-family:Consolas; font-size:13px;'>");

            // Titulo principal del procedimiento
            html.append("<b>Metodo de Interpolacion de Lagrange (Grado ")
                    .append(n).append(")</b><br><br>");

            // Mostrar formula general segun el grado seleccionado
            html.append("<b>1) Formula general:</b><br>");

            if (n == 1) {
                // Formula de grado 1 (lineal)
                html.append("f(x) = y<sub>0</sub>(x-x<sub>1</sub>)/(x<sub>0</sub>-x<sub>1</sub>) + "
                        + "y<sub>1</sub>(x-x<sub>0</sub>)/(x<sub>1</sub>-x<sub>0</sub>)<br><br>");
            }
            else if (n == 2) {
                // Formula de grado 2 (cuadratica)
                html.append("f(x)= y<sub>0</sub>(x-x<sub>1</sub>)(x-x<sub>2</sub>)/((x<sub>0</sub>-x<sub>1</sub>)(x<sub>0</sub>-x<sub>2</sub>))<br>");
                html.append("  + y<sub>1</sub>(x-x<sub>0</sub>)(x-x<sub>2</sub>)/((x<sub>1</sub>-x<sub>0</sub>)(x<sub>1</sub>-x<sub>2</sub>))<br>");
                html.append("  + y<sub>2</sub>(x-x<sub>0</sub>)(x-x<sub>1</sub>)/((x<sub>2</sub>-x<sub>0</sub>)(x<sub>2</sub>-x<sub>1</sub>))<br><br>");
            }
            else if (n == 3) {
                // Formula de grado 3 (cubica)
                html.append("f(x)= Sigma y<sub>i</sub> * L<sub>i</sub>(x) <br><br>");
            }

            // Sustitucion de valores numericos
            html.append("<b>2) Sustitucion numerica:</b><br>");

            double resultado = 0;         // acumulador del resultado final
            double[] fi = new double[n+1]; // cada termino Yi * Li


            // Bucle principal de Lagrange
            for (int i = 0; i <= n; i++) {

                // Escribe la estructura del termino f_i
                html.append("f<sub>").append(i).append("</sub> = ")
                        .append(Y.get(i)).append(" * ");

                double Li = 1; // valor del polinomio base L_i(x)

                // Construccion del producto de Lagrange
                for (int j = 0; j <= n; j++) {

                    if (i != j) {

                        // Muestra la fraccion (x - xj) / (xi - xj)
                        html.append("((").append(xEval).append(" - ")
                                .append(X.get(j)).append(") / (")
                                .append(X.get(i)).append(" - ")
                                .append(X.get(j)).append("))");

                        // Multiplica el valor real de L_i
                        Li *= (xEval - X.get(j)) / (X.get(i) - X.get(j));
                    }
                }

                // Guarda el valor total del termino i
                fi[i] = Li * Y.get(i);

                // Salto de linea
                html.append("<br>");
            }

            // Evaluacion de cada termino numerico
            html.append("<br><b>3) Evaluacion:</b><br>");

            for (int i = 0; i <= n; i++) {

                // Muestra T_i con 6 decimales
                html.append("f<sub>").append(i).append("</sub> = ")
                        .append(String.format("%.6f", fi[i]))
                        .append("<br>");

                // Acumula al resultado final
                resultado += fi[i];
            }

            // Resultado final de f(x)
            html.append("<br><b>4) Resultado final:</b><br>");
            html.append("f(").append(xEval).append(") = ")
                    .append(String.format("%.6f", resultado))
                    .append("<br>");

            // Cierre del HTML
            html.append("</body></html>");

            // Pasa todo el contenido al panel HTML
            htmlSteps.setText(html.toString());

            // Actualiza el label grande de resultado (color negro + azul)
            lblResultado.setText(
                "<html><span style='color:black;'>Resultado de f(x)= </span>"
              + "<span style='color:#003399;'>" + resultado + "</span></html>"
            );


        } catch (Exception ex) {

            // Manejo de cualquier error numerico o conversion
            JOptionPane.showMessageDialog(this,
                    "Error en los datos ingresados",
                    "Advertencia",
                    JOptionPane.ERROR_MESSAGE);
        }
    }

    // Estilo botones suaves

    /**
     * Crea un boton con estilo azul suave y animaciones al pasar el mouse.
     * No afecta la logica, solo la apariencia visual.
     *
     * @param text texto que mostrara el boton
     * @return JButton personalizado
     */
    private JButton blueButton(String text) {

        JButton b = new JButton(text);                       // crea el boton con el texto recibido
        b.setPreferredSize(new Dimension(130, 28));          // tamano fijo para que se vean iguales
        b.setBackground(new Color(120, 145, 175));           // color azul suave inicial
        b.setForeground(Color.WHITE);                        // texto blanco
        b.setFont(new Font("SansSerif", Font.BOLD, 11));     // fuente sencilla y legible
        b.setFocusPainted(false);                            // quita el borde de enfoque feo

        // Listener para cambiar color cuando el usuario interactua con el boton
        b.addMouseListener(new MouseAdapter() {

            @Override public void mouseEntered(MouseEvent e) {
                b.setBackground(new Color(105, 130, 160));   // color un poco mas oscuro al pasar el mouse
            }

            @Override public void mousePressed(MouseEvent e) {
                b.setBackground(new Color(85, 110, 145));    // color mas oscuro al presionar
            }

            @Override public void mouseReleased(MouseEvent e) {
                b.setBackground(new Color(105, 130, 160));   // vuelve al color de hover cuando suelta
            }

            @Override public void mouseExited(MouseEvent e) {
                b.setBackground(new Color(120, 145, 175));   // vuelve al color original al salir
            }
        });

        return b;  // retorna el boton ya estilizado
    }
    
    // Filtro numerico (solo permite decimales validos)
    
    /**
     * Filtro para que las celdas de la tabla solo acepten numeros decimales.
     * Este filtro permite valores como:
     *  - 5
     *  - 5.25
     *  - -1.75
     *  - (campo vacio mientras el usuario escribe)
     */
    private class NumericFilter extends DocumentFilter {

        @Override
        public void insertString(FilterBypass fb, int off, String s, AttributeSet a)
                throws BadLocationException {

            if (isValid(fb, s))          // verifica que el texto sea valido
                super.insertString(fb, off, s, a);  // si es valido, lo inserta
        }

        @Override
        public void replace(FilterBypass fb, int off, int len, String s, AttributeSet a)
                throws BadLocationException {

            if (isValid(fb, s))          // verifica el texto nuevo
                super.replace(fb, off, len, s, a);  // reemplaza si es valido
        }

        /**
         * Verifica si el texto ingresado es un numero decimal valido.
         */
        private boolean isValid(FilterBypass fb, String text) throws BadLocationException {

            if (text == null) return true;     // si no hay texto, no pasa nada

            // obtiene lo que habia escrito antes
            String prev = fb.getDocument().getText(0, fb.getDocument().getLength());

            // simula como quedaria el texto despues del cambio
            String futuro = prev + text;

            // permite: signo -, numeros, punto decimal
            return futuro.matches("-?\\d*(\\.\\d*)?");
        }
    }

    // Metodo main (inicio del programa)

    /**
     * Metodo principal. Lanza la interfaz grafica.
     */
    public static void main(String[] args) {

        // Ejecuta la interfaz en el hilo especial de Swing
        SwingUtilities.invokeLater(InterpolacionGUI::new);
    }
}

