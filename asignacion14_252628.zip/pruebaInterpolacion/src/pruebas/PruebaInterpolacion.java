package pruebas;

import implementaciones.Interpolacion;

/**
 * Clase auxiliar para ejecutar pruebas o validar resultados.
 * No contiene metodo main.
 *
 * @author PC EXPRESS NAVOJOA
 */
public class PruebaInterpolacion {

    public static double caso1() {
        Interpolacion interp = new Interpolacion();
        double[][] puntos = {
            {3.0, 5.25},
            {5.0, 19.75}
        };
        int n = 1;
        return interp.interpolacionLagrange(puntos, n, 3.5);
    }

    public static double caso2() {
        Interpolacion interp = new Interpolacion();
        double[][] puntos = {
            {2.0, 4.0},
            {3.0, 5.25},
            {5.0, 19.75}
        };
        int n = 2;
        return interp.interpolacionLagrange(puntos, n, 3.5);
    }

    public static double caso3() {
        Interpolacion interp = new Interpolacion();
        double[][] puntos = {
            {2.0, 4.0},
            {3.0, 5.25},
            {5.0, 19.75},
            {6.0, 36.0}
        };
        int n = 3;
        return interp.interpolacionLagrange(puntos, n, 3.5);
    }
}
