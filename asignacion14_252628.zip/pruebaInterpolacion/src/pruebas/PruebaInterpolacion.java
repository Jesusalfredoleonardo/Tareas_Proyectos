package pruebas;

import implementaciones.Interpolacion;

/**
 * Clase principal para ejecutar los casos solicitados en la asignacion.
 * Calcula f1(3.5), f2(3.5) y f3(3.5) segun puntos dados.
 *
 * @author PC EXPRESS NAVOJOA
 */
public class PruebaInterpolacion {

    public static void main(String[] args) {
        Interpolacion interp = new Interpolacion();

        // Caso 1: Interpolacion lineal (grado 1) usando puntos (3,5.25) y (5,19.75)
        double puntos1[][] = {
            {3.0, 5.25},
            {5.0, 19.75}
        };
        int n1 = 1;
        double xEval = 3.5;
        System.out.println("CASO 1: Interpolacion lineal (grado 1)");
        interp.despliegaPuntos(puntos1, n1);
        double f1 = interp.interpolacionLagrange(puntos1, n1, xEval);
        System.out.printf("f1(%.6f) = %.6f\n\n", xEval, f1);

        // Caso 2: Interpolacion cuadratica (grado 2) puntos (2,4),(3,5.25),(5,19.75)
        double puntos2[][] = {
            {2.0, 4.0},
            {3.0, 5.25},
            {5.0, 19.75}
        };
        int n2 = 2;
        System.out.println("CASO 2: Interpolacion cuadratica (grado 2)");
        interp.despliegaPuntos(puntos2, n2);
        double f2 = interp.interpolacionLagrange(puntos2, n2, xEval);
        System.out.printf("f2(%.6f) = %.6f\n\n", xEval, f2);

        // Caso 3: Interpolacion cubica (grado 3) puntos (2,4),(3,5.25),(5,19.75),(6,36)
        double puntos3[][] = {
            {2.0, 4.0},
            {3.0, 5.25},
            {5.0, 19.75},
            {6.0, 36.0}
        };
        int n3 = 3;
        System.out.println("CASO 3: Interpolacion cubica (grado 3)");
        interp.despliegaPuntos(puntos3, n3);
        double f3 = interp.interpolacionLagrange(puntos3, n3, xEval);
        System.out.printf("f3(%.6f) = %.6f\n\n", xEval, f3);

        // Imprimir resumen
        System.out.println("RESUMEN:");
        System.out.printf("f1(%.6f) = %.6f\n", xEval, f1);
        System.out.printf("f2(%.6f) = %.6f\n", xEval, f2);
        System.out.printf("f3(%.6f) = %.6f\n", xEval, f3);

        // Lanzar la interfaz grafica (opcional)
        javax.swing.SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                InterpolacionGUI gui = new InterpolacionGUI();
                gui.setVisible(true);
            }
        });
    }
}
