package implementaciones;

import java.text.DecimalFormat;
/**
/**
* @author PC EXPRESS NAVOJOA
 * Esta clase se encarga de resolver sistemas de ecuaciones lineales
 * usando los metodos de Gauss y Gauss-Jordan con pivoteo parcial.
 * Tambien permite mostrar las matrices y resultados con el numero
 * de decimales que el usuario elija desde el spinner.
 */

public class SolucionEcuaciones {

    // Este objeto sirve para dar formato a los numeros (cuantos decimales mostrar)
    // Por defecto mostramos 4 decimales
    private static DecimalFormat formato = new DecimalFormat("0.0000");

    /**
     * Cambia el formato decimal que se usa para mostrar resultados.
     * Este metodo lo llama el JFrame principal cuando se cambia el spinner.
     * @param nuevoFormato El nuevo formato decimal
     */
    public static void setFormato(DecimalFormat nuevoFormato) {
        formato = nuevoFormato;
    }

    // PRIMER METODO, ELIMINACION DE GAUSS 

    /**
     * Resuelve un sistema de ecuaciones usando Eliminacion de Gauss con pivoteo.
     * @param a Matriz ampliada del sistema (coeficientes + columna de resultados)
     * @return Arreglo con la solucion del sistema
     */
    public double[] eliminacionGauss(double[][] a) {
        int n = a.length;

        // Paso 1: Hacer la eliminacion hacia adelante (convertir a triangular)
        eliminacionAdelante(a);

        // Paso 2: Sustitucion hacia atras (resolver las variables)
        double[] x = new double[n];
        return sustitucionAtras(a, x);
    }

    /**
     * Hace ceros debajo del pivote para formar una matriz triangular superior.
     * @param a Matriz ampliada del sistema
     */
    public void eliminacionAdelante(double[][] a) {
        int n = a.length;

        for (int i = 0; i < n - 1; i++) {
            // Paso 1: elegir el mejor pivote (valor mas grande en la columna)
            pivotea(a, i);

            // Paso 2: verificar que no sea cero (evita division entre 0)
            if (Math.abs(a[i][i]) < 1e-10) {
                throw new ArithmeticException("Sistema singular (no se puede resolver)");
            }

            // Paso 3: eliminar los valores debajo del pivote
            for (int j = i + 1; j < n; j++) {
                double factor = a[j][i] / a[i][i];
                for (int k = i; k <= n; k++) {
                    a[j][k] = a[j][k] - factor * a[i][k];
                }
            }
        }
    }

    /**
     * Busca el elemento mas grande en la columna actual y lo usa como pivote.
     * Esto evita errores numericos y hace el metodo mas estable.
     * @param a Matriz ampliada
     * @param i Fila actual
     */
    public void pivotea(double[][] a, int i) {
        int n = a.length;
        int filaPivote = i;
        double maxValor = Math.abs(a[i][i]);

        // Buscar el elemento mas grande en la columna
        for (int k = i + 1; k < n; k++) {
            if (Math.abs(a[k][i]) > maxValor) {
                maxValor = Math.abs(a[k][i]);
                filaPivote = k;
            }
        }

        // Si se encontro uno mas grande, se intercambian las filas
        if (filaPivote != i) {
            double[] temp = a[i];
            a[i] = a[filaPivote];
            a[filaPivote] = temp;
        }
    }

    /**
     * Resuelve una matriz triangular superior usando sustitucion hacia atras.
     * Calcula los valores de las incognitas empezando desde la ultima fila.
     * @param a Matriz triangular superior
     * @param x Arreglo donde se guarda la solucion
     * @return Solucion del sistema
     */
    public double[] sustitucionAtras(double[][] a, double[] x) {
        int n = a.length;

        if (Math.abs(a[n - 1][n - 1]) < 1e-10) {
            throw new ArithmeticException("Sistema singular (no se puede resolver)");
        }

        // Resolver la ultima variable primero
        x[n - 1] = a[n - 1][n] / a[n - 1][n - 1];

        // Luego resolver las demas hacia arriba
        for (int i = n - 2; i >= 0; i--) {
            double suma = 0.0;
            for (int j = i + 1; j < n; j++) {
                suma += a[i][j] * x[j];
            }
            x[i] = (a[i][n] - suma) / a[i][i];
        }

        return x;
    }

    // SEGUNDO METODO, GAUSS-JORDAN 

    /**
     * Resuelve un sistema de ecuaciones usando Gauss-Jordan con pivoteo.
     * Convierte la matriz en una forma diagonal donde se obtienen directamente las soluciones.
     * @param a Matriz ampliada del sistema
     * @return Arreglo con las soluciones
     */
    public double[] gaussJordan(double[][] a) {
        int n = a.length;

        for (int i = 0; i < n; i++) {
            pivotea(a, i);

            if (Math.abs(a[i][i]) < 1e-10) {
                throw new ArithmeticException("Sistema singular (no se puede resolver)");
            }

            // Normalizar la fila para que el pivote sea 1
            double pivote = a[i][i];
            for (int j = 0; j <= n; j++) {
                a[i][j] = a[i][j] / pivote;
            }

            // Hacer ceros arriba y abajo del pivote
            for (int k = 0; k < n; k++) {
                if (k != i) {
                    double factor = a[k][i];
                    for (int j = 0; j <= n; j++) {
                        a[k][j] = a[k][j] - factor * a[i][j];
                    }
                }
            }
        }

        // Sacar las soluciones (estan en la ultima columna)
        double[] x = new double[n];
        for (int i = 0; i < n; i++) {
            x[i] = a[i][n];
        }

        return x;
    }

    // METODOS AUXILIARES

    /**
     * Muestra la matriz ampliada con el formato de decimales actual.
     * @param a Matriz ampliada
     * @return Texto con la matriz formateada
     */
    public String despliegaMatrizAmpliada(double[][] a) {
        StringBuilder sb = new StringBuilder();
        int n = a.length;

        sb.append("Matriz Ampliada:\n");
        for (int i = 0; i < n; i++) {
            sb.append("[ ");
            for (int j = 0; j <= n; j++) {
                if (j == n) {
                    sb.append("| ");
                }
                sb.append(String.format("%10s ", formato.format(a[i][j])));
            }
            sb.append("]\n");
        }
        sb.append("\n");
        return sb.toString();
    }

    /**
     * Muestra las soluciones del sistema con el formato de decimales actual.
     * @param x Arreglo con las soluciones
     * @return Texto con la solucion formateada
     */
    public String despliegaSolucion(double[] x) {
        StringBuilder sb = new StringBuilder();
        sb.append("Solucion del sistema:\n");
        for (int i = 0; i < x.length; i++) {
            sb.append("x").append(i + 1).append(" = ")
              .append(formato.format(x[i])).append("\n");
        }
        sb.append("\n");
        return sb.toString();
    }

    /**
     * Crea una copia de una matriz (para no modificar la original).
     * @param original Matriz que se quiere copiar
     * @return Copia de la matriz
     */
    public double[][] copiarMatriz(double[][] original) {
        int filas = original.length;
        int columnas = original[0].length;
        double[][] copia = new double[filas][columnas];

        for (int i = 0; i < filas; i++) {
            for (int j = 0; j < columnas; j++) {
                copia[i][j] = original[i][j];
            }
        }

        return copia;
    }
}
