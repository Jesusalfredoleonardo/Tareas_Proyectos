package MetodosGauss;

import javax.swing.*;
import javax.swing.border.TitledBorder;
import javax.swing.event.ChangeEvent;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableColumn;
import java.awt.*;
import java.text.DecimalFormat;
import java.util.Arrays;
import java.util.Random;

/**
 *@author PC EXPRESS NAVOJOA
 * 
 * Incluye:
 * - Gauss (eliminacion)
 * - Gauss-Jordan
 * - Gauss-Seidel (en ventana separada con scroll horizontal y vertical)
 */
public class GaussSeidelFrame extends JFrame {

    // Modelos y tablas
    private DefaultTableModel modelInputSmall;
    private JTable tableInputSmall;

    private DefaultTableModel modelSteps;
    private JTable tableSteps;
    private JScrollPane spSteps;

    // Controles
    private JComboBox<String> cbMetodo;
    private JComboBox<String> cbDefaultsGS;
    private JSpinner spSize, spDecimals, spIterations;
    private JTextField txtErrorMax;
    private JButton btnEjecutar, btnClear;

    // Formato decimal
    private DecimalFormat df;

    // Colores (tema azul)
    private final Color BTN_BG = new Color(0, 102, 204);
    private final Color BTN_HOVER = new Color(0, 128, 255);
    private final Color BTN_TEXT = Color.WHITE;
    private final Color COMBO_BG = new Color(230, 240, 255);

    public GaussSeidelFrame() {
        initComponents();
    }

    private void initComponents() {
        setTitle("Gauss, Gauss-Jordan y Gauss-Seidel");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setSize(1200, 820);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout(8, 8));
        setResizable(false);

        //TOP PANEL
        JPanel top = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 8));
        cbMetodo = new JComboBox<>(new String[]{"Gauss", "Gauss-Jordan", "Gauss-Seidel"});
        cbDefaultsGS = new JComboBox<>(new String[]{"-- Ninguna --", "25x25 (A)", "30x30 (B)", "50x50 (C)"});
        spSize = new JSpinner(new SpinnerNumberModel(3, 2, 1000, 1));
        spDecimals = new JSpinner(new SpinnerNumberModel(4, 0, 10, 1));
        spIterations = new JSpinner(new SpinnerNumberModel(500, 1, 100000, 1));
        txtErrorMax = new JTextField("0.1", 6);
        btnEjecutar = new JButton("Ejecutar");
        btnClear = new JButton("Limpiar");

        top.add(new JLabel("Metodo:"));
        top.add(cbMetodo);
        top.add(btnEjecutar);
        top.add(btnClear);
        top.add(new JLabel(" Ecuaciones:"));
        top.add(spSize);
        top.add(new JLabel(" Decimales:"));
        top.add(spDecimals);
        top.add(new JLabel(" Iteraciones (GS):"));
        top.add(spIterations);
        top.add(new JLabel(" Error max % (eai):"));
        top.add(txtErrorMax);
        top.add(new JLabel(" Matrices GS:"));
        top.add(cbDefaultsGS);

        add(top, BorderLayout.NORTH);

        //INPUT TABLE
        modelInputSmall = new DefaultTableModel();
        tableInputSmall = new JTable(modelInputSmall);
        tableInputSmall.setFont(new Font("SansSerif", Font.PLAIN, 14));
        tableInputSmall.setRowHeight(24);
        JScrollPane spInputSmall = new JScrollPane(tableInputSmall,
                JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED,
                JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
        spInputSmall.setPreferredSize(new Dimension(1150, 260));
        spInputSmall.setBorder(new TitledBorder("Matriz aumentada (A | b) - editar / pegar"));

        //STEPS TABLE
        modelSteps = new DefaultTableModel();
        tableSteps = new JTable(modelSteps);
        tableSteps.setFont(new Font(Font.MONOSPACED, Font.PLAIN, 12));
        tableSteps.setRowHeight(22);
        spSteps = new JScrollPane(tableSteps,
                JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED,
                JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
        spSteps.setPreferredSize(new Dimension(1150, 460));
        spSteps.setBorder(new TitledBorder("Pasos / Resultados"));

        JPanel center = new JPanel();
        center.setLayout(new BoxLayout(center, BoxLayout.Y_AXIS));
        center.add(spInputSmall);
        center.add(Box.createRigidArea(new Dimension(0, 8)));
        center.add(spSteps);
        add(center, BorderLayout.CENTER);

        //CONFIG INICIAL
        updateDecimalFormat();
        updateMatrixSmallSize();
        adjustInputColumnWidthsSmall();

        // Listeners
        spSize.addChangeListener((ChangeEvent e) -> {
            updateMatrixSmallSize();
            adjustInputColumnWidthsSmall();
        });

        spDecimals.addChangeListener(e -> updateDecimalFormat());

        cbMetodo.addActionListener(e -> {
            String metodo = (String) cbMetodo.getSelectedItem();
            boolean isGS = "Gauss-Seidel".equals(metodo);
            spSteps.setVisible(!isGS);
            spIterations.setEnabled(isGS);
            cbDefaultsGS.setEnabled(isGS);
            txtErrorMax.setEnabled(isGS);
            // ajustar rango spSize
            if (isGS) {
                int curr = (Integer) spSize.getValue();
                int val = Math.max(2, Math.min(curr, 50));
                spSize.setModel(new SpinnerNumberModel(val, 2, 50, 1));
            } else {
                int curr = (Integer) spSize.getValue();
                int val = Math.max(2, Math.min(curr, 1000));
                spSize.setModel(new SpinnerNumberModel(val, 2, 1000, 1));
            }
        });

        cbDefaultsGS.addActionListener(e -> {
            if (cbDefaultsGS.getSelectedIndex() == 0) return;
            if (!"Gauss-Seidel".equals(cbMetodo.getSelectedItem())) {
                JOptionPane.showMessageDialog(this,
                        "Seleccione primero el metodo Gauss-Seidel para usar las matrices predeterminadas.",
                        "Aviso", JOptionPane.INFORMATION_MESSAGE);
                cbDefaultsGS.setSelectedIndex(0);
                return;
            }
            applyDefaultGS(cbDefaultsGS.getSelectedIndex());
        });

        btnEjecutar.addActionListener(e -> ejecutarMetodoSeleccionado());
        btnClear.addActionListener(e -> {
            modelSteps.setRowCount(0);
            updateMatrixSmallSize();
        });

        applyBlueStyle();

        cbMetodo.setSelectedIndex(0);
    }

    //Estilo azul
    private void applyBlueStyle() {
        JButton[] botones = {btnEjecutar, btnClear};
        for (JButton b : botones) {
            b.setBackground(BTN_BG);
            b.setForeground(BTN_TEXT);
            b.setFocusPainted(false);
            b.setOpaque(true);
            b.addMouseListener(new java.awt.event.MouseAdapter() {
                public void mouseEntered(java.awt.event.MouseEvent evt) {
                    b.setBackground(BTN_HOVER);
                }
                public void mouseExited(java.awt.event.MouseEvent evt) {
                    b.setBackground(BTN_BG);
                }
            });
        }

        JComboBox<?>[] combos = {cbMetodo, cbDefaultsGS};
        for (JComboBox<?> c : combos) {
            c.setBackground(COMBO_BG);
            c.setForeground(Color.BLACK);
            c.setOpaque(true);
        }

        // alinear numeros a la derecha en las tablas
        DefaultTableCellRenderer right = new DefaultTableCellRenderer();
        right.setHorizontalAlignment(DefaultTableCellRenderer.RIGHT);
        tableInputSmall.setDefaultRenderer(Object.class, right);
        tableSteps.setDefaultRenderer(Object.class, right);
    }

    //Helpers UI
    private void updateDecimalFormat() {
        int dec = (Integer) spDecimals.getValue();
        StringBuilder pat = new StringBuilder("0");
        if (dec > 0) {
            pat.append(".");
            for (int i = 0; i < dec; i++) pat.append("0");
        }
        df = new DecimalFormat(pat.toString());
    }

    private void updateMatrixSmallSize() {
        int n = (Integer) spSize.getValue();
        if (n < 2) n = 2;
        String[] cols = new String[n + 1];
        for (int i = 0; i < n; i++) cols[i] = "x" + (i + 1);
        cols[n] = "b";
        Object[][] data = new Object[n][n + 1];
        for (int i = 0; i < n; i++) for (int j = 0; j < n + 1; j++) data[i][j] = "0";
        modelInputSmall.setDataVector(data, cols);
    }

    private void adjustInputColumnWidthsSmall() {
        tableInputSmall.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
        FontMetrics fm = tableInputSmall.getFontMetrics(tableInputSmall.getFont());
        for (int c = 0; c < tableInputSmall.getColumnCount(); c++) {
            TableColumn col = tableInputSmall.getColumnModel().getColumn(c);
            int max = fm.stringWidth(col.getHeaderValue().toString()) + 18;
            for (int r = 0; r < tableInputSmall.getRowCount(); r++) {
                Object v = tableInputSmall.getValueAt(r, c);
                if (v != null) {
                    int w = fm.stringWidth(v.toString()) + 18;
                    if (w > max) max = w;
                }
            }
            col.setPreferredWidth(Math.max(60, Math.min(max, 200)));
        }
    }

    private double[][] getMatrixFromSmall() throws Exception {
        int rows = modelInputSmall.getRowCount();
        int cols = modelInputSmall.getColumnCount();
        double[][] A = new double[rows][cols];
        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < cols; j++) {
                Object cell = modelInputSmall.getValueAt(i, j);
                if (cell == null || cell.toString().trim().isEmpty())
                    throw new Exception("Celda vacia en fila " + (i + 1) + ", columna " + (j + 1));
                try {
                    A[i][j] = Double.parseDouble(cell.toString().trim());
                } catch (NumberFormatException ex) {
                    throw new Exception("Valor no numerico en fila " + (i + 1) + ", columna " + (j + 1));
                }
            }
        }
        return A;
    }

    //Ejecutar metodo seleccionado
    private void ejecutarMetodoSeleccionado() {
        try {
            String metodo = (String) cbMetodo.getSelectedItem();
            double[][] A = getMatrixFromSmall();
            modelSteps.setRowCount(0);

            switch (metodo) {
                case "Gauss":
                    gaussEliminationWithSteps(A);
                    adjustStepsColumnWidthsAndHeights();
                    break;
                case "Gauss-Jordan":
                    gaussJordanWithSteps(A);
                    adjustStepsColumnWidthsAndHeights();
                    break;
                case "Gauss-Seidel":
                    double tolPercent;
                    try {
                        tolPercent = Double.parseDouble(txtErrorMax.getText().trim());
                        if (tolPercent < 0) throw new NumberFormatException();
                    } catch (Exception ex) {
                        JOptionPane.showMessageDialog(this,
                                "Error: el valor de Error max debe ser un numero positivo. Ej: 0.1",
                                "Error", JOptionPane.ERROR_MESSAGE);
                        return;
                    }
                    int maxIter = (Integer) spIterations.getValue();
                    openGaussSeidelWindow(A, maxIter, tolPercent);
                    break;
                default:
                    JOptionPane.showMessageDialog(this, "Metodo no soportado", "Error", JOptionPane.ERROR_MESSAGE);
            }
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    //GAUSS
    private void gaussEliminationWithSteps(double[][] A) throws Exception {
        int n = A.length;
        int m = A[0].length;
        modelSteps.setDataVector(new Object[][]{}, new String[]{"Paso", "Accion", "Descripcion"});

        // copia para no destrozar entrada visual
        double[][] M = deepCopy(A);

        for (int k = 0; k < n - 1; k++) {
            // pivoteo parcial
            int piv = k;
            for (int i = k + 1; i < n; i++)
                if (Math.abs(M[i][k]) > Math.abs(M[piv][k])) piv = i;
            if (Math.abs(M[piv][k]) < 1e-14)
                throw new Exception("Pivote casi cero en columna " + (k + 1));
            if (piv != k) {
                swapRows(M, k, piv);
                modelSteps.addRow(new Object[]{"Pivoteo", "Intercambiar R" + (k + 1) + " <-> R" + (piv + 1), matrixToString(M)});
            }
            for (int i = k + 1; i < n; i++) {
                double factor = M[i][k] / M[k][k];
                for (int j = k; j < m; j++) M[i][j] -= factor * M[k][j];
                modelSteps.addRow(new Object[]{"Eliminacion", "m" + (i + 1) + (k + 1) + "=" + df.format(factor), rowToString(M[i])});
            }
        }

        // sustitucion hacia atras
        double[] x = new double[n];
        for (int i = n - 1; i >= 0; i--) {
            double s = M[i][m - 1];
            for (int j = i + 1; j < n; j++) s -= M[i][j] * x[j];
            x[i] = s / M[i][i];
        }

        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < n; i++) sb.append("x").append(i + 1).append("=").append(df.format(x[i])).append(" ");
        modelSteps.addRow(new Object[]{"Resultado", "Solucion", sb.toString()});
    }

    //GAUSS-JORDAN
    private void gaussJordanWithSteps(double[][] A) throws Exception {
        int n = A.length;
        int m = A[0].length;
        modelSteps.setDataVector(new Object[][]{}, new String[]{"Paso", "Accion", "Descripcion"});

        double[][] M = deepCopy(A);

        for (int k = 0; k < n; k++) {
            // pivoteo parcial
            int piv = k;
            for (int i = k + 1; i < n; i++)
                if (Math.abs(M[i][k]) > Math.abs(M[piv][k])) piv = i;
            if (Math.abs(M[piv][k]) < 1e-14)
                throw new Exception("Pivote casi cero en columna " + (k + 1));
            if (piv != k) {
                swapRows(M, k, piv);
                modelSteps.addRow(new Object[]{"Pivoteo", "Intercambiar R" + (k + 1) + " <-> R" + (piv + 1), matrixToString(M)});
            }
            double diag = M[k][k];
            for (int j = k; j < m; j++) M[k][j] /= diag;
            modelSteps.addRow(new Object[]{"Normalizar", "R" + (k + 1) + " /= " + df.format(diag), rowToString(M[k])});
            for (int i = 0; i < n; i++) {
                if (i == k) continue;
                double f = M[i][k];
                for (int j = k; j < m; j++) M[i][j] -= f * M[k][j];
                modelSteps.addRow(new Object[]{"Eliminacion", "R" + (i + 1) + " -= " + df.format(f) + "*R" + (k + 1), rowToString(M[i])});
            }
        }

        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < n; i++) sb.append("x").append(i + 1).append("=").append(df.format(M[i][m - 1])).append(" ");
        modelSteps.addRow(new Object[]{"Resultado", "Solucion", sb.toString()});
    }

    private void adjustStepsColumnWidthsAndHeights() {
        tableSteps.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
        FontMetrics fm = tableSteps.getFontMetrics(tableSteps.getFont());
        for (int c = 0; c < tableSteps.getColumnCount(); c++) {
            TableColumn col = tableSteps.getColumnModel().getColumn(c);
            int maxW = fm.stringWidth(col.getHeaderValue().toString()) + 18;
            for (int r = 0; r < tableSteps.getRowCount(); r++) {
                Object val = tableSteps.getValueAt(r, c);
                if (val != null) {
                    int w = fm.stringWidth(val.toString()) + 18;
                    if (w > maxW) maxW = w;
                }
            }
            int preferred = Math.max(80, Math.min(maxW, 700));
            col.setPreferredWidth(preferred);
        }
        for (int row = 0; row < tableSteps.getRowCount(); row++) tableSteps.setRowHeight(row, 24);
    }

    //GAUSS-SEIDEL (ventana separada)
    private void openGaussSeidelWindow(double[][] matrizOriginal, int maxIter, double tolPercent) throws Exception {
        int n = matrizOriginal.length;
        if (n < 1) throw new Exception("Matriz vacia");
        if (n > 1000) throw new Exception("Matrices muy grandes no soportadas desde la UI");

        JFrame gsWindow = new JFrame("Gauss-Seidel - Vista Ampliada (" + n + "x" + n + ")");
        gsWindow.setSize(1200, 800);
        gsWindow.setLocationRelativeTo(this);
        gsWindow.setLayout(new BorderLayout(8, 8));
        gsWindow.setResizable(true);

        JPanel top = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 8));
        top.add(new JLabel("Iteraciones max: " + maxIter));
        top.add(new JLabel("Tolerancia (eai%): " + tolPercent));
        gsWindow.add(top, BorderLayout.NORTH);

        DefaultTableModel modelIter = new DefaultTableModel();
        JTable tblIter = new JTable(modelIter);
        tblIter.setFont(new Font(Font.MONOSPACED, Font.PLAIN, 12));
        tblIter.setRowHeight(20);
        tblIter.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);

        // JScrollPane con scrolls siempre según demanda
        JScrollPane spIter = new JScrollPane(tblIter,
                JScrollPane.VERTICAL_SCROLLBAR_ALWAYS,
                JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);
        spIter.setBorder(new TitledBorder("Tabla de iteraciones"));

        JTextArea txtLog = new JTextArea();
        txtLog.setFont(new Font(Font.MONOSPACED, Font.PLAIN, 12));
        txtLog.setEditable(false);
        JScrollPane spLog = new JScrollPane(txtLog,
                JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED,
                JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
        spLog.setBorder(new TitledBorder("Log paso a paso"));

        JSplitPane split = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, spIter, spLog);
        split.setResizeWeight(0.5);
        split.setDividerLocation(600);
        gsWindow.add(split, BorderLayout.CENTER);

        JButton btnClose = new JButton("Cerrar");
        btnClose.addActionListener(e -> gsWindow.dispose());
        JPanel bottom = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        bottom.add(btnClose);
        gsWindow.add(bottom, BorderLayout.SOUTH);

        gsWindow.setVisible(true);

        // Ejecutar y rellenar
        int convIter = ejecutarGaussSeidelEnVentana(matrizOriginal, maxIter, tolPercent, modelIter, txtLog);

        if (convIter > 0) {
            JOptionPane.showMessageDialog(gsWindow, "Convergencia en iteracion " + convIter,
                    "Convergencia", JOptionPane.INFORMATION_MESSAGE);
        } else {
            JOptionPane.showMessageDialog(gsWindow, "No convergio en " + maxIter + " iteraciones.",
                    "Aviso", JOptionPane.WARNING_MESSAGE);
        }

        // Ajuste de anchos de columnas (intentar dar una anchura manejable)
        SwingUtilities.invokeLater(() -> {
            for (int c = 0; c < tblIter.getColumnCount(); c++) {
                TableColumn col = tblIter.getColumnModel().getColumn(c);
                col.setPreferredWidth(120);
            }
        });
    }

    /**
     * Ejecuta Gauss-Seidel y llena la tabla de iteraciones y el log.
     * tolPercent es en porcentaje (ej: 0.1 significa 0.1%).
     * Retorna la iteracion en la que converge, o 0 si no converge.
     */
    private int ejecutarGaussSeidelEnVentana(double[][] A, int maxIter, double tolPercent,
                                              DefaultTableModel modeloTabla, JTextArea areaLog) throws Exception {
        int n = A.length;
        int m = A[0].length;
        if (m != n + 1) throw new Exception("La matriz debe ser aumentada (n x (n+1)).");

        double[][] M = new double[n][n];
        double[] b = new double[n];
        for (int i = 0; i < n; i++) {
            b[i] = A[i][m - 1];
            for (int j = 0; j < n; j++) M[i][j] = A[i][j];
        }

        for (int i = 0; i < n; i++) if (Math.abs(M[i][i]) < 1e-14)
            throw new Exception("Diagonal cerca de cero en fila " + (i + 1));

        // columnas: It | x1..xn | ea1..ean | maxEa%
        String[] cols = new String[1 + n + n + 1];
        cols[0] = "It";
        for (int i = 0; i < n; i++) cols[1 + i] = "x" + (i + 1);
        for (int i = 0; i < n; i++) cols[1 + n + i] = "ea" + (i + 1) + "%";
        cols[cols.length - 1] = "maxEa%";
        modeloTabla.setColumnIdentifiers(cols);
        modeloTabla.setRowCount(0);

        double[] x = new double[n];
        double[] xOld = new double[n];

        areaLog.setText("");
        areaLog.append("Sistema A | b (n=" + n + ")\n");
        for (int i = 0; i < n; i++) {
            StringBuilder sb = new StringBuilder();
            for (int j = 0; j < n; j++) {
                sb.append(df.format(M[i][j])).append(" ");
            }
            sb.append("| ").append(df.format(b[i]));
            areaLog.append(sb.toString());
            areaLog.append("\n");
        }
        areaLog.append("\nIteraciones:\n");

        boolean converged = false;
        int iterConvergence = 0;

        for (int iter = 1; iter <= maxIter; iter++) {
            // Gauss-Seidel: usar x ya actualizado en la misma iteracion
            for (int i = 0; i < n; i++) {
                double sum = 0;
                for (int j = 0; j < n; j++) if (j != i) sum += M[i][j] * x[j];
                x[i] = (b[i] - sum) / M[i][i];
            }

            double[] ea = new double[n];
            double maxEa = 0;
            for (int i = 0; i < n; i++) {
                if (Math.abs(x[i]) < 1e-14) {
                    ea[i] = Double.NaN;
                } else {
                    ea[i] = Math.abs((x[i] - xOld[i]) / x[i]) * 100.0;
                }
                if (!Double.isNaN(ea[i]) && ea[i] > maxEa) maxEa = ea[i];
            }

            Object[] row = new Object[cols.length];
            row[0] = iter;
            for (int i = 0; i < n; i++) row[1 + i] = df.format(x[i]);
            for (int i = 0; i < n; i++) row[1 + n + i] = Double.isNaN(ea[i]) ? "-" : df.format(ea[i]);
            row[row.length - 1] = df.format(maxEa);
            modeloTabla.addRow(row);

            StringBuilder sumRow = new StringBuilder();
            sumRow.append("It ").append(iter).append(" : ");
            for (int i = 0; i < n; i++) sumRow.append("x").append(i + 1).append("=").append(df.format(x[i])).append(" ");
            sumRow.append(" maxEa%=").append(df.format(maxEa));
            areaLog.append(sumRow.toString());
            areaLog.append("\n");

            if (!Double.isNaN(maxEa) && maxEa < tolPercent) {
                converged = true;
                iterConvergence = iter;
                break;
            }

            xOld = Arrays.copyOf(x, n);
        }

        if (!converged) {
            areaLog.append("\nNo convergio en " + maxIter + " iteraciones.\n");
            return 0;
        } else {
            areaLog.append("\nConvergencia alcanzada en iteracion " + iterConvergence + "\n");

            //Verificacion A·x ≈ b
            areaLog.append("\nVerificacion Ax ≈ b:\n");
            double[] bcalc = multiplyMatrixVector(M, x);
            for (int i = 0; i < n; i++) {
                areaLog.append("Ec " + (i + 1) + " LHS=" + df.format(bcalc[i]) +
                               "  RHS=" + df.format(b[i]) + "\n");
            }

            return iterConvergence;
        }

    }

    //UTILIDADES
    private void swapRows(double[][] A, int r1, int r2) {
        double[] tmp = A[r1];
        A[r1] = A[r2];
        A[r2] = tmp;
    }

    private double[] multiplyMatrixVector(double[][] A, double[] v) {
        double[] r = new double[A.length];
        for (int i = 0; i < A.length; i++) {
            double s = 0;
            for (int j = 0; j < v.length; j++) s += A[i][j] * v[j];
            r[i] = s;
        }
        return r;
    }

    private String matrixToString(double[][] A) {
        StringBuilder sb = new StringBuilder();
        for (double[] row : A) {
            sb.append("[");
            for (int j = 0; j < row.length; j++) {
                sb.append(df.format(row[j]));
                if (j < row.length - 1) sb.append(", ");
            }
            sb.append("] ");
        }
        return sb.toString();
    }

    private String rowToString(double[] r) {
        StringBuilder sb = new StringBuilder("[");
        for (int j = 0; j < r.length; j++) {
            sb.append(df.format(r[j]));
            if (j < r.length - 1) sb.append(", ");
        }
        sb.append("]");
        return sb.toString();
    }

    private double[][] deepCopy(double[][] M) {
        double[][] R = new double[M.length][M[0].length];
        for (int i = 0; i < M.length; i++) R[i] = Arrays.copyOf(M[i], M[i].length);
        return R;
    }

    //MATRICES PREDETERMINADAS GS
    private void applyDefaultGS(int idx) {
        try {
            int n = (idx == 1) ? 25 : (idx == 2) ? 30 : 50;
            double[][] ex = generateDiagonalDominant(n, idx);
            spSize.setValue(n);
            String[] cols = new String[n + 1];
            for (int i = 0; i < n; i++) cols[i] = "x" + (i + 1);
            cols[n] = "b";
            Object[][] data = new Object[n][n + 1];
            for (int i = 0; i < n; i++) for (int j = 0; j < n + 1; j++) data[i][j] = df.format(ex[i][j]);
            modelInputSmall.setDataVector(data, cols);
            adjustInputColumnWidthsSmall();
        } catch (Exception ex) {
            // no falla el programa si hay error de generacion
            JOptionPane.showMessageDialog(this, "Error al generar matriz predeterminada: " + ex.getMessage(),
                    "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private double[][] generateDiagonalDominant(int n, int seedOffset) {
        double[][] A = new double[n][n + 1];
        Random rnd = new Random(1234 + n + seedOffset);
        for (int i = 0; i < n; i++) {
            double sum = 0;
            for (int j = 0; j < n; j++) {
                if (i == j) continue;
                double val = Math.round((rnd.nextDouble() * 10 - 5) * 100.0) / 100.0;
                A[i][j] = val;
                sum += Math.abs(val);
            }
            double diag = Math.round((sum + 1 + rnd.nextDouble() * 5) * 100.0) / 100.0;
            A[i][i] = diag;
            A[i][n] = Math.round((rnd.nextDouble() * 20 - 10) * 100.0) / 100.0;
        }
        return A;
    }

    //MAIN
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            GaussSeidelFrame f = new GaussSeidelFrame();
            f.setVisible(true);
        });
    }
}