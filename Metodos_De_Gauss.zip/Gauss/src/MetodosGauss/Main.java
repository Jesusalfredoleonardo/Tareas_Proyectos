package MetodosGauss;

/**
 * Main: arranca la GUI (llama al JFrame creado por código).
 */
public class Main {
    public static void main(String[] args) {
        // Lanza la interfaz en el hilo de eventos de Swing
        javax.swing.SwingUtilities.invokeLater(() -> {
            new GaussSeidelFrame().setVisible(true);
        });
    }
}
